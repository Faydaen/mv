<?php
/**
 * Локализация
 */
class ProjectLang extends Lang
{
    const PROJECT_NAME = "Contentico Project";
}

class Lang
{
    const CONTENTICO = "Contentico v2";

    /**
     * Генерация строки
     *
     * @param string $text
     * @param array $params
     * @return string
     */
    public static function renderText($text, $params)
    {
        foreach ($params as $code => $value) {
            $text = str_replace('<%' . $code . '%>', $value, $text);
        }
        return $text;
    }
}
?>
