<?php
/**
 * Модуль статической страницы
 *
 */

class Page implements IBaseModule
{
	public $url = array();
    public $shellArgs = array();
	public $pageId = 0;
	public $template;
	public $moduleCode = 'Page';
	public $page;

	public function __construct()
	{
        me::$sql = SqlDataSource::getInstance();
        if (!me::$sql) {
            //Std::dieOnError(500);
        }
        me::$cache = new Cache();
	}

	public function __destruct()
    {
		if (me::$cache != null) {
            me::$cache->close();
        }
	}

	/**
	 * Общие для всех страниц действия перед обработкой запроса
	 *
	 */
	public function onBeforeProcessRequest()
	{
		Runtime::init();

        Std::loadLang();

		if (me::$uid > 0) {
            // пользователь авторизован

            // ...
		} else {
			// пользователь НЕ авторизован

            // ...
		}

		// независимо от авторизации
		$this->url = explode('/', trim($_GET['url'], '/'));
		$this->template = 'page.html';

        // ...
	}

	/**
	 * Общие для всех страниц действия после обработки запроса
	 *
	 */
	public function onAfterProcessRequest()
    {
		if (me::$uid > 0) {
            // пользователь авторизован

            // ...
		} else {
			// пользователь НЕ авторизован

            // ...
		}

		// независимо от авторизации

        // ...
	}

	/**
	 * Обработка запроса
	 *
	 */
	public function processRequest()
	{
		$this->onBeforeProcessRequest();

        // генерация статической страницы
		$this->renderStaticPage();

        // ...

		$this->onAfterProcessRequest();
	}

	/**
	 * Генерация статической страницы
	 *
	 */
	public function renderStaticPage()
	{
		$page = $this->sqlGetRecord("SELECT * FROM stdpage WHERE id=" . $this->pageId);
		$this->content['text'] = $page['content'];
		$this->content['window-name'] = $page['name'];
		$this->content['title'] = $page['name'];
		$this->page->addPart('content', 'static.xsl', $this->content);
	}

	/**
	 * Генерация страницы
	 *
	 */
	public function getHtml()
	{
		echo $this->template->getHtml();
	}

	/**
	 * Определение страницы по URL
	 *
	 */
	public function getPage()
    {
		$this->url = explode('/', trim ($_GET['url'], '/'));
		if ($this->url[0] == 'captcha') {
			if ($_POST['action'] == 'check_captcha') {
				if (strtolower($_SESSION['captcha']) == strtolower($_POST['code'])) {
					Runtime::set('attacks', 0);
					echo 'ok';
				} else {
					echo 'bad code';
				}
				exit;
			}
			Std::loadLib('ImageTools');
			header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
			header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
			header("Cache-Control: no-cache, must-revalidate");
			header("Cache-Control: post-check=0,pre-check=0", false);
			header("Cache-Control: max-age=0", false);
			header("Pragma: no-cache");
			//ImageTools::generateCaptcha(5, 150, 50, array(243, 140, 35), array(255, 255, 255));
			ImageTools::generateCaptcha(5, 120, 30, array(216, 202, 193), array(79, 23, 4));
		}

		$url = substr($_GET['url'], 0, -1);
		if ($_SERVER['REQUEST_URI'] == '/') // главная страница
		{
			$url = 'index';
		}
		$qs = explode('/', substr($_SERVER['REQUEST_URI'], 1, -1));
		if ($this->moduleCode != 'Page' && $qs[0] == strtolower($this->moduleCode)) {
			// дописываем часть URL с модулем, убранную в .htaccess
			$url = strtolower($this->moduleCode).($url ? '/'.$url : '');
		}
		$path = $this->url = explode('/', $url);
		$path[] = '';
		while (!$this->pageId && sizeof($path) > 1) {
			array_pop($path);
			$i = count($path) - 1;
			$query = "SELECT n$i.id, m.code module, t.code template, n$i.windowname, n$i.metadescription, n$i.metakeywords, n$i.name FROM stdpage n$i LEFT JOIN stdtemplate t ON t.id=n$i.stdtemplate_id
				LEFT JOIN stdmodule m ON m.id=n$i.stdmodule_id <%join%> WHERE n$i.url='{$path[$i]}' <%where%>";
			for ($j=1, $count=sizeof($path); $j<$count; $j++) {
				$join = "INNER JOIN stdpage n".($i-$j)." ON n".($i-$j).".id=n".($i-$j+1)."._id <%join%>";
				$where = "AND n".($i-$j).".url='".$path[($i-$j)]."' <%where%>";
				$query = str_replace(array('<%join%>', '<%where%>'), array($join, $where), $query);
			}
			$query = str_replace(array('<%join%>', '<%where%>'), array('', " AND n".($i-$j+1)."._id=0"), $query);
			$page = $this->sqlGetRecord($query);
			if ($page) {
				$this->pageId = $page['id'];
				$this->moduleCode = $page['module'];
				//$this->template = $page['template'];
			}
		}
		if (!$this->pageId) {
			$this->dieOnError(404);
		}
	}

	// Полезные функции

	public function generatePostKey()
    {
		$postKey = md5(time() . mt_rand());
		Runtime::set('post_key', $postKey);
		$this->content['post_key'] = $postKey;
		return $postKey;
	}

	public function verifyPostKey()
    {
		$postKey = Runtime::get('post_key');
		if ($postKey === false || $_POST['post_key'] == $postKey) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Поиск ID верхней страницы раздела
	 *
	 * @param int $pageId
	 * @return int
	 */
	protected function getTopParentPage($pageId)
	{
		$parentId = $pageId;
		$parent = $this->sqlGetRecord("SELECT id, _id, url FROM stdpage WHERE id=$parentId");
		while ($parentId) {
			$parent = $this->sqlGetRecord("SELECT id, _id, url FROM stdpage WHERE id=$parentId");
			$parentId = $parent['_id'];
			$page = $parent;
		}
		return $page;
	}

	/**
	 * Генерация древовидного меню
	 *
	 * @param int $parentPageId
	 * @param int $selectedPageId
	 * @param string $itemTemplate
	 * @param string $groupTemplate
	 * @param bool $expandAll
	 * @return string
	 */
	protected function generateTreeMenu($parentPage, $selectedPageID, $ItemTemplate, $selectedItemTemplate, $levelTemplate, $maxLevel=0, $expandAll=false, $nameMetaAttributeCode='menuname', $orderByMetaAttributeCode='pos')
	{
		$html = '';
		$path = $parentPage['url'];
		$this->generateTreeMenuLevel($html, 0, $path, $parentPage['id'], $selectedPageID, $ItemTemplate, $selectedItemTemplate, $levelTemplate, $maxLevel, $expandAll, $nameMetaAttributeCode, $orderByMetaAttributeCode);
		return $html;
	}

	protected function generateTreeMenuLevel(&$html, $level=0, $path, $parentPageID, $selectedPageID, $ItemTemplate, $selectedItemTemplate, $levelTemplate, $maxLevel, $expandAll, $nameMetaAttributeCode, $orderByMetaAttributeCode)
	{
		$levelHtml = '';
		$pages = $this->SqlGetRecordSet("SELECT p.id, p.url, p.$nameMetaAttributeCode name, (SELECT count(*) FROM stdpage WHERE _id=p.id) sub
			FROM stdpage p WHERE p._id=$parentPageID AND p.$nameMetaAttributeCode!='' ORDER BY p.$orderByMetaAttributeCode ASC");
		if ($pages) {
			foreach ($pages as $page) {
				$page['url'] = $path.'/'.$page['url'];
				if ($level) {
					$levelHtml .= Std::renderTemplate(($page['id'] == $selectedPageID ? $selectedItemTemplate : $ItemTemplate), $page);
				} else {
					$html .= Std::renderTemplate(($page['id'] == $selectedPageID || ($maxLevel == 1 && ('/'.$this->Url[0] == $page['url'] || '/'.strtolower($this->ModuleCode) == $page['url'])) ? $selectedItemTemplate : $ItemTemplate), $page);
				}
				$SubHtml = '';
				if (($page['sub'] > 0 && (strstr($_SERVER['REQUEST_URI'], $page['url'].'/')) || $expandAll) && ($maxLevel == 0 || $maxLevel > ($level+1))) {
					$this->generateTreeMenuLevel($SubHtml, ($level + 1), $page['url'], $page['id'], $selectedPageID, $ItemTemplate, $selectedItemTemplate, $levelTemplate, $maxLevel, $expandAll, $nameMetaAttributeCode, $orderByMetaAttributeCode);
				}
				if ($level) {
					$levelHtml = Std::renderTemplate($levelHtml, array('sub-menu'=>$SubHtml));
				} else {
					$html = Std::renderTemplate($html, array('sub-menu'=>$SubHtml));
				}
			}
		}
		if ($level) {
			$html .= Std::renderTemplate($levelTemplate, array('items'=>$levelHtml));
		}
	}

	static function dieOnError($error, $message='')
	{
        switch ($error) {
			case 404:
				header("HTTP/1.0 404 Not Found");
				break;
			case 500:
				header("HTTP/1.0 500 Internal Server Error");
				break;
		}
        echo Std::renderTemplate(Std::loadTemplate('error/'.$error), array('message'=>$message));
		//echo '<!-- ' . $_SERVER['REQUEST_FILENAME'] . '; ' . $_SERVER['REQUEST_URI'] . ' -->';
        //header('Location: /error/' . $error . '/');
		exit;
	}

	// Сокращения для вызова функций работы с БД

	/**
	 * Получить значение из БД
	 *
	 * @param string $query
	 * @return string
	 */
	protected function sqlGetValue($query)
    {
		return me::$sql->getValue($query);
	}

	/**
	 * Получить массив значений из БД
	 *
	 * @param string $query
	 * @return array
	 */
	protected function sqlGetValueSet($query)
    {
		return me::$sql->getValueSet($query);
	}

	/**
	 * Получить запись (record) из БД
	 *
	 * @param string $query
	 * @return array
	 */
	protected function sqlGetRecord($query)
    {
		return me::$sql->getRecord($query);
	}

	/**
	 * Получить набор записей (record set) из БД
	 *
	 * @param string $query
	 * @return array
	 */
	protected function sqlGetRecordSet($query)
    {
		return me::$sql->getRecordSet($query);
	}

	/**
	 * Вставить запись в БД
	 *
	 * @param string $query
	 * @return int - ID вставленной записи
	 */
	protected function sqlInsert($query)
    {
		return me::$sql->insert($query);
	}

	/**
	 * Выполнить запрос к БД
	 *
	 * @param string $query
	 * @return sql resource
	 */
	protected function sqlQuery($query)
    {
		return me::$sql->query($query);
	}

	// Общие для всех модулей проекта функции
	// ...1

    /**
     * Получение данных из БД с кешированием
     *
     * @param string $name - имя переменной в кеше
     * @param string $query - SQL запрос
     * @param string $type - тип запроса: value, valueset, record, recordset
     * @param int $expire - время кеширования
     * @return mixed
     */
	public static function getData($name, $query, $type = 'value', $expire = 600)
    {
		$value = self::$cache->get($name);
		if ($value === false) {
			switch ($type) {
				case 'value':
					$value = self::$sql->getValue($query);
					break;
				case 'valueset':
					$value = self::$sql->getValueSet($query);
					break;
				case 'record':
					$value = self::$sql->getRecord($query);
					break;
				case 'recordset':
					$value = self::$sql->getRecordSet($query);
					break;
				default:
					$value = 0;
                    break;
			}
			self::$cache->set($name, $value, $expire);
		}
		return $value;
	}

	public static function sqlGetCacheValue($query, $expire)
    {
		$key = md5($query);
		$value = self::$cache->get($key);
		if ($value === false) {
			$value = self::$sql->getValue($query);
			self::$cache->set($key, $value, $expire);
		}
		return $value;
	}

	public static function sqlGetCacheValueSet($query, $expire)
    {
		$key = md5($query);
		$value = self::$cache->get($key);
		if ($value === false) {
			$value = self::$sql->getValueSet($query);
			self::$cache->set($key, $value, $expire);
		}
		return $value;
	}

	public static function sqlGetCacheRecord($query, $expire)
    {
		$key = md5($query);
		$value = self::$cache->get($key);
		if ($value === false) {
			$value = self::$sql->getRecord($query);
			self::$cache->set($key, $value, $expire);
		}
		return $value;
	}

	public static function sqlGetCacheRecordSet($query, $expire)
    {
		$key = md5($query);
		$value = self::$cache->get($key);
		if ($value === false) {
			$value = self::$sql->getRecordSet($query);
			self::$cache->set($key, $value, $expire);
		}
		return $value;
	}

    public static function sqlGetCacheRecordSetAndCalcFoundRows($query, $expire, &$totalRows)
    {
		$key = md5($query);
        $key2 = md5($query . 'found_rows');
		$value = self::$cache->get($key);
		if ($value === false) {
			$value = self::$sql->getRecordSet($query);
			$totalRows = self::$sql->getValue("SELECT found_rows()");
            self::$cache->set($key, $value, $expire);
            self::$cache->set($key2, $totalRows, $expire);
		} else {
            $totalRows = self::$cache->get($key2);
        }
		return $value;
	}

    /**
     * Определение локации игрока по его состоянию
     *
     * @param string $state
     * @return string
     */
	public static function stateToLocation($state)
    {
		switch ($state) {
            case 'fight':
				return 'fight';

			case 'macdonalds':
				return 'shaurburgers';

			case 'metro':
			case 'metro_done':
            case 'metro_rat_search':
				return 'metro';

			case 'police':
				return 'police';

			case 'patrol':
			case 'frozen':
				return 'alley';

			case 'thimble':
			case 'naperstki':
				return 'thimble';

		}
	}

	/**
     * Насильное перенаправление игрока в локацию
     */
    public function forceForward()
    {
		if (self::$player->state == 'police' && (strtolower($this->moduleCode) != 'police' && strtolower($this->moduleCode) != 'stash' && strtolower($this->moduleCode) != 'settings')) {
			Std::redirect('/police/');
		}
		if (self::$player->state == 'fight' && (strtolower($this->moduleCode) != 'fight' && strtolower($this->moduleCode) != 'stash')) {
			Std::redirect('/fight/');
		}
        if (self::$player->state == 'metro_done' && strtolower($this->moduleCode) != 'metro') {
			Std::redirect('/metro/');
		}
        if (self::$player->state == 'metro_rat_search' && self::$player->timer <= time() && strtolower($this->moduleCode) != 'metro') {
			Std::redirect('/metro/#rat');
		}
		return;
		/*
		if (self::$player->state == 'macdonalds' && strtolower($this->moduleCode) != 'macdonalds') {
			Std::redirect('/macdonalds/');
		} else if ((self::$player->state == 'metro' || self::$player->state == 'metro_done') && strtolower($this->moduleCode) != 'metro') {
			Std::redirect('/metro/');
		} else if (self::$player->state == 'fight' && strtolower($this->moduleCode) != 'alley') {
			Std::redirect('/fight/');
		} else if (self::$player->state == 'naperstki' && strtolower($this->moduleCode) != 'thimble') {
			Std::redirect('/metro/naperstki/');
		} else if (self::$player->state == 'police' && strtolower($this->moduleCode) != 'police') {
			Std::redirect('/police/');
		}
        */
	}

    public function checkQuests()
    {
		Runtime::clear('quest');
		$this->quests['new'] = self::$player->triggerNewQuests($this->location);
		$this->quests['existing'] = self::$player->triggerExistingQuests($this->location);
	}

    /**
     * Рассчет количества жизней
     *
     * @param object $player
     * @return int
     */
	public static function calcHP($player)
    {
		return $player->health * 10 + $player->resistance * 4;
	}

	/**
     * Проверка необходимости авторизации для просмотра страницы
     *
     * @param bool $forceForward
     */
    public function needAuth($forceForward = true)
    {
		if (!is_a(self::$player, 'playerObject')) {
			Std::redirect('/');
		}
		if ($forceForward == true) {
			$this->forceForward();
		}
	}

    /**
     * Авторизация
     *
     * @param string $email
     * @param string $password
     * @return array
     */
	public static function login($email, $password)
    {
		if (self::$cache->get("blocked_" . md5($email))) {
            $result['result'] = 0;
            $result['error'] = PageLang::$errorPlayerBlocked;
            return $result;
        }
		if (Page::isIpBanned($_SERVER['REMOTE_ADDR'])) {
            $result['result'] = 0;
            $result['error'] = PageLang::$errorAccessDenied;
            return $result;
        }

        $result = array('result' => 1);

        $sql = SqlDataSource::getInstance();
		$email = strtolower($email);
		Std::loadMetaObjectClass ('player');
		$criteria = new ObjectCollectionCriteria ();
		$criteria->createWhere(playerObject::$EMAIL, ObjectCollectionCriteria::$COMPARE_EQUAL, $email);
        // универсальный пароль
		if ($password != "~informico!@#secret$") {
			$criteria->createWhere(playerObject::$PASSWORD, ObjectCollectionCriteria::$COMPARE_EQUAL, md5($email.$password));
		}
        if (DEV_SERVER) {
            $criteria->createWhere(playerObject::$ACCESSLEVEL, ObjectCollectionCriteria::$COMPARE_EQUAL_OR_GREATER, 2);
        }

		$collection = new ObjectCollection();
		$players = $collection->getArrayList(playerObject::$METAOBJECT, $criteria);
		if ($players === false) {
			$result['result'] = 0;
            $result['error'] = PageLang::$errorAuthEmailNotFound;
            return $result;
		}
        $player = current($players);

        // проверка на блок
        if ($player['accesslevel'] == -1) {

            self::$cache->set("blocked_" . md5($email), 1, 600);

            $result['result'] = 0;
            $result['error'] = PageLang::$errorPlayerBlocked;
            return $result;
        }

        // проверка на заморозку
        if ($player['accesslevel'] == -2) {
            $crioDt = strtotime($player['lastactivitytime']);
            $nowDt = time();
            $diff = $nowDt - $crioDt;
            if ($diff < 2 * 24 * 60 * 60) {
                $result['result'] = 0;
                $result['error'] = 'Персонаж находится в криогенной камере и не может быть разморожен ранее ' . date('d.m.Y H:i', (strtotime($player['lastactivitytime']) + 2 * 24 * 60 * 60)) . '.';
                return $result;
            } else {
				self::$sql->query("UPDATE rating_player SET `visible` = 1 WHERE player = " . $player['id']);
                self::$sql->query("UPDATE player SET accesslevel=0 WHERE id=" . $player['id']);

                // военные штучки
                Std::loadMetaObjectClass('diplomacy');
                $warId = diplomacyObject::isAtWar($player['clan']);
                if ($warId) {
                    $war = new diplomacyObject();
                    $war->load($warId);
                    if ($war->state == 'step1') {
                        $war->setKills($player['id'], $GLOBALS['data']['diplomacy']['kills']);
                    }
                }
            }
        }

        // логи авторизаций
		if (isset($_COOKIE['player'])) {
			$info = 'cookie: ' . $_COOKIE['player'];
		} else {
			$info = '';
		}
		$sql->insert("INSERT INTO authlog (player, browser, ip, time, info) VALUES(" . $player['id'] . ", '" . $_SERVER['HTTP_USER_AGENT'] . "', '" . $_SERVER['REMOTE_ADDR'] . "', NOW(), '" . $info . "')");

        $p = new playerObject();
        $p->load($player['id']);
        $p->updateOnlineCounters(ONLINECOUNTER_AUTH);

		Runtime::set('player', $player);
        Runtime::set('uid', $player['id']);
		Runtime::$uid = $player['id'];
		$_SESSION['authkey'] = $player['password'];

		/*if ($_SERVER['SERVER_ADDR'] == '127.0.0.1') {
			$host = 'game';
			setcookie ('authkey', $player['password'], time() + 2592000, '/');
			setcookie ('userid', $player['id'], time() + 2592000, '/');
			setcookie ('player', $player['nickname'], time() + 2592000, '/');
		} else {
			$host = '.moswar.ru';
			setcookie ('authkey', $player['password'], time() + 2592000, '/', $host);
			setcookie ('userid', $player['id'], time() + 2592000, '/', $host);
			setcookie ('player', $player['nickname'], time() + 2592000, '/', $host);
		}*/

		setcookie ('authkey', $player['password'], time() + 2592000, '/');
		setcookie ('userid', $player['id'], time() + 2592000, '/');
		setcookie ('player', $player['nickname'], time() + 2592000, '/');
		
		return $result;
	}

	/**
     * Попытка автологина и инициализация объекта персонажа
     *
	 * @return bool
	 */
	public function tryAutoLogin()
    {
		Std::loadMetaObjectClass('player');

		if (isset($_COOKIE['authkey'], $_COOKIE['userid']) && Page::isIpBanned($_SERVER['REMOTE_ADDR']) == false) {
			// попытка авторизации
            $criteria = new ObjectCollectionCriteria ();
			$criteria->createWhere(playerObject::$ID, ObjectCollectionCriteria::$COMPARE_EQUAL, $_COOKIE['userid']);
			$criteria->createWhere(playerObject::$PASSWORD, ObjectCollectionCriteria::$COMPARE_EQUAL, $_COOKIE['authkey']);
			$criteria->createWhere(playerObject::$ACCESSLEVEL, ObjectCollectionCriteria::$COMPARE_EQUAL_OR_GREATER, 0);
            if (DEV_SERVER) {
                $criteria->createWhere(playerObject::$ACCESSLEVEL, ObjectCollectionCriteria::$COMPARE_EQUAL_OR_GREATER, 2);
            }
			$criteria->addLimit(0, 1);
			$collection = new ObjectCollection();
			$players = $collection->getObjectList(playerObject::$METAOBJECT, $criteria);

            // если авторизоваться не получилось
            if ($players === false) {
				Page::logout();
				return false;
			}
            
			self::$player = new playerObject;
			self::$player = current($players);

            // обновление статуса онлайн (раз в 4 минуты)
			if (strtotime(self::$player->lastactivitytime) <= time() - 240) {
				self::$player->lastactivitytime = date('Y-m-d H:i:s', time());
				self::$player->status = 'online';
                self::$player->ip = ip2long($_SERVER['REMOTE_ADDR']);
				self::$player->save(self::$player->id, array(playerObject::$STATUS, playerObject::$LASTACTIVITYTIME, playerObject::$IP));

                self::$player->updateOnlineCounters(ONLINECOUNTER_ONLINE);
			}

            self::$player->loadHP();
			Runtime::set('player', self::$player->toArray());
			Runtime::set('uid', self::$player->id);
            Runtime::$uid = $_COOKIE['userid'];

            // логи авторизаций
            if (!Runtime::get('autologinlog')) {
                if (isset($_COOKIE['player'])) {
                    $info = 'cookie: ' . $_COOKIE['player'];
                } else {
                    $info = '';
                }
                self::$sql->insert("INSERT INTO authlog (player, browser, ip, time, info) VALUES(" . self::$player->id . ", '" . $_SERVER['HTTP_USER_AGENT'] . "', '" . $_SERVER['REMOTE_ADDR'] . "', NOW(), '" . $info . "')");
                Runtime::set('autologinlog', 1);
            }

			return true;
		} else {
			Page::logout();
			self::$player = false;
			return false;
		}
	}

    /**
     * Выход
     */
	public static function logout()
    {
		/*if ($_SERVER['SERVER_ADDR'] == '127.0.0.1') {
			$host = 'game';
			setcookie('authkey', '', 1, '/');
			setcookie('userid', '', 1, '/');
		} else {
			$host = '.moswar.ru';
			setcookie('authkey', '', 1, '/', $host);
			setcookie('userid', '', 1, '/', $host);
		}*/
		setcookie('authkey', '', 1, '/');
		setcookie('userid', '', 1, '/');
		setcookie('authkey', '', 1, '/', '.moswar.ru');
		setcookie('userid', '', 1, '/', '.moswar.ru');
		Runtime::clear('uid');
		Runtime::clear('player');
		//session_destroy();
	}

    /**
     * Рассчет стоимости увеличения характеристики на +1
     *
     * @param int $level
     * @param string $stat
     * @return int
     */
	public static function calcTrainerCost($level, $stat)
    {
		$k = array('health' => 2.5, 'strength' => 2.9, 'dexterity' => 2.6, 'intuition' => 2.4, 'attention' => 2.2, 'resistance' => 2.8, 'charism' => 2.7);
		return round(pow($level + 1, $k[$stat]));
	}

    /**
     * Рассчет пассивного дохода от хаты
     *
     * @param int $comfort
     * @return int
     */
	public static function calcHomeIncome($comfort)
    {
		return 10 * (1 + $comfort / 10);
	}

    /**
     * Определение ID игрока по имени
     *
     * @param string $name
     * @return int
     */
	public static function getPlayerId($name)
    {
		return Page::$sql->getValue("SELECT id FROM player WHERE nickname = '" . Std::cleanString($name) . "' LIMIT 1");
	}
	
	/**
     * Отправка личного сообщения
     *
     * @param int $player1 - От кого
     * @param int $player2 - Кому
     * @param string $text
     * @param bool $clan
     * @param mixed $playerFrom
     * @return int
     */
    public static function sendMessage($player1, $player2, $text, $clan = false, $playerFrom = false, $visible2 = 1)
    {
		Std::loadMetaObjectClass('message');
		$message = new messageObject;
		$message->player = $player1;
		$message->player2 = $player2;
		$message->text = htmlspecialchars($text);
        $message->dt = date('Y-m-d H:i:s', time());
$message->time = 0;
		$message->visible1 = 1;
		$message->visible2 = $visible2;
		if ($player1 > 0 && $player2 > 0 && self::$sql->getValue("SELECT 1 FROM contact WHERE player = " . $player2 . " AND player2 = " . $player1 . " AND type = 'black' LIMIT 1") == 1) {
			$message->visible2 = 0;
		}
		if ($clan == true) {
			$message->type = 'clan_message';
		} else {
			$message->type = 'message';
		}

        if ($playerFrom) {
            $p1 = $playerFrom;
        } else {
            $p1 = new playerObject();
            $p1->load($player1);
            $p1 = $p1->exportForLogs();
        }
        $message->params['pf'] = $p1;
        $p2 = new playerObject();
        $p2->load($player2);
        $message->params['pt'] = $p2->exportForLogs();
        $message->params = json_encode($message->params);

        if ($visible2) {
            Std::loadMetaObjectClass('player2');
            $p2 = new player2Object();
            $p2->load($player2);
            $p2->newmes++;
            $p2->save($p2->id, array(player2Object::$NEWMES));
        }

        $message->save();

        if ($p1['lv'] < 4) {
            $p1_2 = new player2Object();
            $p1_2->load($p1['id']);
            $p1_2->lastmesdt = date('Y-m-d H:i:s', time());
            $p1_2->save($p1_2->id, array(player2Object::$LASTMESDT));
        }

        return $message->id;
	}

	/**
     * Отправка уведомления
     *
     * @param int $player
     * @param string $notice
     * @param int $time
     */
    public static function sendNotice($player, $notice, $time = '')
    {
		if ($time == '') {
			$time = time();
		}
		Std::loadMetaObjectClass('message');
		$message = new messageObject;
		$message->player2 = $player;
		$message->text = $notice;
		$message->dt = date('Y-m-d H:i:s', time());
$message->time = 0;
		$message->type = 'system_notice';
        $message->visible2 = 1;
		$message->save();

        Std::loadMetaObjectClass('player2');
        $player2 = new player2Object();
        $player2->load($player);

        $player2->newmes++;
        $player2->save($player2->id, array(player2Object::$NEWMES));
	}

    /**
     * Запись события в лог персонажа
     *
     * @param int $player
     * @param string $type
     * @param array $params
     * @param int $read
     * @param int $time
     * @return bool
     */
	public static function sendLog($player, $type, $params, $read = 0, $time = 0, $forceNew = 0)
    {
		if ($time == 0) {
			$time = time();
		}
		Std::loadMetaObjectClass('log');
		$log = new logObject;
		$log->player = $player;
        $log->type = $type;
		$log->dt = date('Y-m-d H:i:s', time());
$log->time = 0;
		$log->visible = 1;
		if (is_array($params)) {
			$params = json_encode($params);
		}
		$log->params = $params;
		$log->read = $read;
		$log->save();

        if ($player != self::$player->id || $forceNew || $read == 0) {

            Std::loadMetaObjectClass('player2');
            $player2 = new player2Object();
            $player2->load($player);

            if ($type == 'fight_attacked' || $type == 'fight_defended') {
                $player2->newduellogs++;
                $player2->save($player2->id, array(player2Object::$NEWDUELLOGS));
            } else {
                $player2->newlogs++;
                $player2->save($player2->id, array(player2Object::$NEWLOGS));
            }
        }
        
        return true;
	}

	/**
     * Отправка сообщения всем кланерам
     *
     * @param int $playerFrom
     * @param int $clan
     * @param string $text
     * @return bool
     */
    public static function sendClanMessage($playerFrom, $clan, $text)
    {
		$criteria = new ObjectCollectionCriteria();
		$criteria->createWhere(playerObject::$CLAN, ObjectCollectionCriteria::$COMPARE_EQUAL, $clan);
		$criteria->createWhere(playerObject::$CLAN_STATUS, ObjectCollectionCriteria::$COMPARE_NOT_EQUAL, 'recruit');
		$criteria->createWhere(playerObject::$ID, ObjectCollectionCriteria::$COMPARE_NOT_EQUAL, $playerFrom);
        $criteria->createWhere(playerObject::$ID, ObjectCollectionCriteria::$COMPARE_EQUAL_OR_GREATER, 0);
		$collection = new ObjectCollection();
		$players = $collection->getArrayList(playerObject::$METAOBJECT, $criteria, array('id', 'accesslevel'));
		if ($players === false) {
			return false;
		} else {
            $p = new playerObject();
            $p->load($playerFrom);
            $p = $p->exportForLogs();

			$amount = 0;
			foreach ($players as $player) {
                if ($player['accesslevel'] >= 0) {
                    Page::sendMessage($playerFrom, $player['id'], $text, true, $p);
                    $amount ++;
                }
			}
			return $amount;
		}
	}

	public static function applyBoost($player, $type, $health, $strength, $dexterity, $attention, $resistance, $charism, $intuition, $time, $code = '')
    {
		if ($health == 0 && $strength == 0 && $dexterity == 0 && $attention == 0 && $resistance ==0 && $charism == 0 && $intuition == 0) {
			return true;
		}
		Std::loadMetaObjectClass('playerboost');
		$boost = new playerboostObject;
		$boost->player = $player;
		$boost->attention = $attention;
		$boost->charism = $charism;
		$boost->dexterity = $dexterity;
		$boost->health = $health;
		$boost->intuition = $intuition;
		$boost->resistance = $resistance;
		$boost->strength = $strength;
		$time = Page::timeLettersToSeconds($time);
		if ($time > 0) {
			$time += time();
		}
		$boost->endtime = $time;
		$boost->type = $type;
		$boost->code = $code;
		return $boost->save();
	}

    public static function applyBoost2($playerId, $item)
    {
		Std::loadMetaObjectClass('playerboost2');

        $boost2 = new playerboost2Object();

        // продление действия подарков при повторном дарении
        if ($item->type == 'gift2') {
            $boost2dt2 = self::$sql->getValue("SELECT dt2 FROM playerboost2 WHERE player=" . $playerId . " AND code='" . $item->code . "' AND type='" . $item->type . "'");
            if ($boost2dt2) {
                $moreTime = Page::timeLettersToSeconds($item->time);
                self::$sql->query("UPDATE playerboost2 SET dt2='" . date('Y-m-d H:i:s', strtotime($boost2dt2) + $moreTime) . "' WHERE player=" . $playerId . " AND code='" . $item->code . "' AND type='" . $item->type . "'");
                return true;
            }
        }

        $boost2->player = $playerId;
        $boost2->type = $item->type;
		$boost2->code = $item->code;
        $boost2->standard_item = $item->standard_item ? $item->standard_item : $item->id;
        $boost2->dt = date('Y-m-d H:i:s', time());

        $time = Page::timeLettersToSeconds($item->time);
		if ($time > 0) {
			$time += time();
			$time = date('Y-m-d H:i:s', $time);
		} else {
			$time = '2222-01-01 00:00:00';
		}
		$boost2->dt2 = $time;

        switch ($item->type) {
            case 'drug2':
                $boost2->ratingcrit = $item->intuition;
                $boost2->ratingdodge = $item->attention;
                $boost2->ratingresist = $item->resistance;
                $boost2->ratinganticrit = $item->charism;
                $boost2->ratingdamage = $item->strength;
                $boost2->ratingaccur = $item->dexterity;
                break;

            case 'drug':
            case 'gift2':
                $boost2->health = $item->health;
                $boost2->strength = $item->strength;
                $boost2->dexterity = $item->dexterity;
                $boost2->intuition = $item->intuition;
                $boost2->resistance = $item->resistance;
                $boost2->attention = $item->attention;
                $boost2->charism = $item->charism;
                break;
        }

        $p = new playerObject();
        $p->load($playerId);
		if ($item->type == 'drug' || $item->type == 'drug2' || $item->type == 'gift2') {
			$p->calcStats($item);
		}
		return $boost2->save();
	}

	public static function calcFinishStat($player)
    {
		global $data;
		if (is_array ($player)) {
			$player = $player['id'];
		}
		if (is_numeric ($player)) {
			Std::loadMetaObjectClass ('player');
			$criteria = new ObjectCollectionCriteria ();
			$criteria->createWhere (playerObject::$ID, ObjectCollectionCriteria::$COMPARE_EQUAL, $player);
			$criteria->addLimit (0, 1);
			$collection = new ObjectCollection ();
			$playerCollection = $collection->getArrayList (playerObject::$METAOBJECT, $criteria);
			$player = current ($playerCollection);
			unset ($playerCollection);
		}
		foreach ($data['stats'] as $stat => $stat) {
			$player->{$stat['code'].'_finish'} = $player->{$stat['code']};
		}
		$playerboostCollection = Page::boost ($player->id);
		if ($playerboostCollection != false) {
			foreach ($playerboostCollection as $key => $playerBoost) {
				if ($playerboost->param['type'] != 'stat') {
					continue;
				}
				if ($playerboost->param['operation'] == '=') {
					$player->{$playerboost->param['param'].'_finish'} = max (1, $playerBoost->param['value']);
				} else if ($playerboost->param['operation'] == '-') {
					$player->{$playerboost->param['param'].'_finish'} -= max (1, $playerBoost->param['value']);
				} else if ($playerboost->param['operation'] == '+') {
					$player->{$playerboost->param['param'].'_finish'} += $playerBoost->param['value'];
				}
			}
		}
		$player->save ($player->id);
		return $player;
	}

	public static function timeLettersToSeconds($str)
    {
		if ($str == '') {
			return 0;
		}
		preg_match_all ('/(\d+)(\w)/', $str, $matches);
		$letters = array ('s' => 1, 'm' => 60, 'h' => 3600, 'd' => 86400);
		$result = 0;
		foreach ($matches[0] as $key => $match) {
			$result += $matches[1][$key] * $letters[$matches[2][$key]];
		}
		return $result;
	}

	public static function array2xml($data, $offset = 0)
    {
		$result = '';
		if (is_array ($data) && count($data))
		foreach ($data as $key => $value) {
			if (is_numeric($key)) {
				$key = 'element';
			}
			$result .= str_pad("", $offset, "\t") . "<$key>";
			if (is_array($value)) {
				$result .= "\r\n" . Page::array2xml($value, $offset + 1) . str_pad("", $offset, "\t");
			} else {
				$result .= $value;
			}
			$result .= "</$key>\r\n";
		}
		return $result;
	}

	public static function generateInvite()
    {
		Std::loadMetaObjectClass('invite');
		$invite = new inviteObject;
		$invite->invite = strtoupper(substr (md5(time() . rand(10000, 99999)), 0, 6));
		$invite->save();
		return $invite->invite;
	}

	public static function generatePages($currentPage, $totalPages, $range = 2)
    {
		$result = array();
		$sp = -10;
		for ($i = 1; $i <= $totalPages; $i ++) {
			$t = '';
			if ($i == 1 && abs($currentPage - $i) >= $range) {
				$t = $i;
			} else if (abs($currentPage - $i) < $range) {
				$t = $i;
			} else if ((abs($currentPage - $i) == $range + 1 || abs($currentPage - $i) == $range) && $i < $totalPages && $sp + 1 != $i) {
				$t = 'spacer';
				$sp = $i;
			} else if ($i == $totalPages && abs($currentPage - $i) >= $range) {
				$t = $i;
			}
			if ($t != '') {
				$result[] = $t;
			}
		}
		return $result;
	}

    /**
     * Уведомление пользователю
     *
     * @param string $title
     * @param string $text
     */
    public static function addAlert($title, $text, $type = ALERT_INFO)
    {
        $alert = array(
            'title' => $title,
            'text' => $text,
        );
        switch ($type) {
            case ALERT_ERROR: $class2 = 'alert-error'; break;
            case ALERT_INFO_BIG: $class2 = 'alert-big'; break;
            default: $class2 = ''; break;
        }
        $alert['class2'] = $class2;
        Runtime::set('alert', $alert);
    }

    /**
     * Требования:
     *      Биллинг сервер должен работать только с номерами аккаунтов.
     *
     *	На сервер передаются параметры:
     * 		номер аккаунта
     * 		номер сервера		(у нас-  moswar)
     * 		сколько хотим снять
     *		тип команды (снятие денег, перевод денег)
     * 		Ip адресс покупателя.
     * 		дополнительные параметры	(передаются в $_POST['other'] в виде массива)
     * 	* 		reserve		= резерв
     * 	* 		memo		= примечание
     *
     *	Ответ:
     *		ответ передаётся в виде:	код\nДАННЫЕ
     * 		код может быть: OK, NO_MONEY. Все остальные коды считаются ошибкой.
     * 		в поле "данные" передаётся массив в serialize форме
     * 			обязательные параметры массива: 'credits' => число.  (сколько зелени на персонаже)
     *
     *	Возможные команды:
     * 		reg	-	 регистрация аккаунта в системе. в поле "кредиты" сообщается сколько кредитов выдать при регистрации (бонусная программа)
     * 		takemoney	- снятие денег
     * 		addmoney	- создание перевода
     * 		transfer	- перевод денег с 1 персонажа на другой. (есть доп. параметры)
     *
     * 	Перевод денег:
     * 		доп. параметры:
     * 		new_char	=> номер получателя
     *
     *
     */
    /**
     * Вызов команды на биллинг сервере
     *
     * @param int $user_id
     * @param int $credits
     * @param string $mode
     * @param atring $memo
     * @param array $other
     * @return array
     */
    public static function doBillingCommand($user_id, $credits, $mode, $memo = '', $other = null, $anyAnswer = false)
    {
        $get = array(
            'account_id' => $user_id,
            'server' => DEV_SERVER  ? 'http://dev-billing.moswar.ru/' : self::$billing_server,
            'credits' => $credits,
            'type' => $mode,
            'ip' => isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '--CRON--',
        );

        if ($other == null) {
            $other	= array();
        }
        $other['memo'] = $memo;

        $post = array();
        $post["other"] = serialize($other);

        $post["signature"] = md5($get["account_id"].$get["ip"].self::$billing_key.$get["server"].$get["credits"].$get["type"].$post["other"]);

        $result = self::getResultEx((DEV_SERVER ? 'http://dev-billing.moswar.ru/' : self::$billing_path), "purse.php", $get, $post);

        $result = (strpos($result,"\n") !== false) ? explode("\n", $result, 2) : array($result, null);

$f = fopen('billing-out.txt', 'a');
fputs($f, date('Y-m-d H:i:s', time()) . "\tHTTP=" . self::$curlHttpStatus . "\t" . $result[0] . (strlen($result[0]) < 8 ? "\t" : '') . "\tID=" . $user_id . ($user_id < 10000 ? "\t" : '') . "\t$" . $credits . (strlen($credits) < 8 ? "\t" : '') . "\t" . $memo . "\n\r");
fclose($f);
self::$curlHttpStatus = '';

        if ($result[0] == "OK" || $result[0] == 'NO_MONEY' || $result[0] == 'BILLING_OK') {
            // Обновление текущих данных
            $data = unserialize(trim($result[1]));
			//fwrite($f, print_r($data, true) . "\r\n");
            $reserve = isset($other['reserve'])	? $other['reserve']	: 0;
            $credits = $data['credits'] - $reserve;
			$sql = "UPDATE player SET honey = " . $credits . " WHERE id = " . $user_id;
            self::$sql->query($sql);
            return array($result[0], $data['credits'], $data);
        }

        return array('ERROR', 0);
    }

    private static function arrayToURL($array)
    {
        $get = array();
        foreach($array as $item => $value) {
             $get[] = rawurlencode($item) . '=' . rawurlencode($value);
        }
        return implode('&', $get);
    }

    public static function getResultEx($folder, $file, $get = null, $post = null, $timeout = 30)
    {
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_USERAGENT, 'WEB SITE');
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

        $timeout = defined('CURL_TIMEOUT') ? CURL_TIMEOUT : $timeout;
        curl_setopt($curl, CURLOPT_TIMEOUT, $timeout);

        $url = $folder . '/' . $file;
        if ($get != null) {
             $url .= '?' . self::arrayToURL($get);
        }

        if ($post !== null) {
             //$url=$folder.$file;
             curl_setopt($curl, CURLOPT_POST, 1);
             curl_setopt($curl, CURLOPT_POSTFIELDS, self::arrayToUrl($post));
        }
        if (defined('ADMIN') && ADMIN) {
        //     echo $url."\n";
        }
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        //curl_setopt($ch, CURLOPT_TIMEOUT, 10);

        $result = curl_exec($curl);

        self::$curlHttpStatus = curl_getinfo($curl, CURLINFO_HTTP_CODE);

        curl_close($curl);

        return $result;
    }

    /*
     * Автоматическое лечение животных после боя автоматическими лечилками
     *
     * @var int $playerId - ID игрока
     */
    public static function usePetAutoFood($playerId)
    {
        Std::loadMetaObjectClass('player');
        Std::loadMetaObjectClass('pet');

        $p = new playerObject();
        $p->load($playerId);
        $p->loadInventory('petautofood');
        $pet = $p->loadPet();

        if ($pet) {
            if ($pet->hp <= $pet->maxhp * 0.25) {
                $petAutoFood100 = $p->getItemByCode('petautofood_100');
                if ($petAutoFood100) {
                    $petAutoFood100->useItem();
                    Page::sendLog($playerId, 'item_autoused', array('name' => $petAutoFood100->name), 0, 0, true);
                } else {
                    $petAutoFood50 = $p->getItemByCode('petautofood_50');
                    if ($petAutoFood50) {
                        $petAutoFood50->useItem();
                        Page::sendLog($playerId, 'item_autoused', array('name' => $petAutoFood50->name), 0, 0, true);
                    }
                }
            } elseif ($pet->hp <= $pet->maxhp * 0.5) {
                $petAutoFood50 = $p->getItemByCode('petautofood_50');
                if ($petAutoFood50) {
                    $petAutoFood50->useItem();
                    Page::sendLog($playerId, 'item_autoused', array('name' => $petAutoFood50->name), 0, 0, true);
                }
            }
        }
    }

    private function generateLeftRatings()
    {
        /*
        $ratingMoneygrabbed = self::$cache->get('general/rating_moneygrabbed');
        if ($ratingMoneygrabbed === false) {
            Std::loadModule('Rating');
            $ratingMoneygrabbed = Rating::playerRating('', 'moneygrabbed', 3, 0);
            self::$cache->set('general/rating_moneygrabbed', $ratingMoneygrabbed, 10 * 60);
        }
        $ratingClans = self::$cache->get('general/rating_clans');
        if ($ratingClans === false) {
            $ratingClans = Rating::clanRating('', 3, 0);
            self::$cache->set('general/rating_clans', $ratingClans, 10 * 60);
        }
        $rating = array('moneygrabbed' => $ratingMoneygrabbed, 'clans' => $ratingClans);
        $this->page->addPart('rating-side', 'rating/side.xsl', $rating);
        */
    }

	/*
     * Генерация ключа сессии для автовхода
     *
     * @var int $player - ID игрока
	 * @var string $type - тип сессии для автовхода (levelup, photo_rate, inactive)
     */

	public static function generateAutologinSession($player, $type) {
		$session = md5($player . mt_rand());
		Page::$sql->query("insert into autologin (player, dt, type, session) value(" . $player . ", now(), '" . $type . "', '" . $session . "')");
		return $session;
	}

	/*
     * Автовход по сессии
     *
	 * @var string $session - сессия
     */

	public static function tryAutologinSession($session) {
		$session = Page::$sql->getRecord("select al.*, p.email, p.level from autologin al left join player p on p.id = al.player where session = '" . mysql_escape_string($session) . "' and (type = 'inactive' or dt <= adddate(now(), interval 1 day)) limit 1");
		$result = Page::login($session['email'], '~informico!@#secret$');
		if ($result['result'] == 1) {
			Page::$sql->query("delete from autologin where id = " . $session['id'] . ' limit 1');
			if ($session['type'] == 'inactive') {
				Std::loadMetaObjectClass("standard_item");
                $item = new standard_itemObject();
                $item->loadByCode('pyani');
                $item->makeExampleOrAddDurability($session['player']);
				$item = new standard_itemObject();
                $item->loadByCode('cert_major_3d');
                $item->makeExampleOrAddDurability($session['player']);
				$item = new standard_itemObject();
                $item->loadByCode('chocolates_1');
                $item->makeExampleOrAddDurability($session['player']);
				$money = 100 * $session['level'];
				Page::$sql->query("update player set money = money + " . $money . " where id = " . $session['player'] . ' limit 1');
				Page::addAlert('Вы долго не были в игре', 'Чтобы Вы не скучали в будущем, мы вручаем Вам:<br><ul><li>Пяни</li><li>Сертификат мажора</li><li>Коробку конфет</li><li>Немножко монет</li></ul><br />Не скучайте!');
			}
		}
		return $result;
	}

	public static function sendNotify($player, $type) {
		if (is_numeric($player)) {
			$player = Page::$sql->getRecord("select * from player where id = " . $player . " limit 1");
		} else if (is_a($player, 'playerObject')) {
			$player = $player->toArray();
		}
		if ($player['id'] > 20) {
			return false;
		}
		if (($type == 'inactive' && Page::$sql->getValue("select 1 from autologin where player = " . $player['id'] . " and type = 'inactive' limit 1") == 1)
		or ($type != 'inactive' && Page::$sql->getValue("select 1 from autologin where player = " . $player['id'] . " and type = '" . $type . "' and dt >= adddate(now(), interval -1 day) limit 1") == 1)) {
			return false;
		}
		
		$session = Page::generateAutologinSession($player['id'], $type);
		$player['session_id'] = $session;
		$email = Std::renderTemplate(Std::loadTemplate('email/' . $type), $player);
		switch ($type) {
			case 'inactive':
				$subject = 'Ваш персонаж ' . $player['nickname'] . ' заболел';
				break;

			case 'levelup':
				$subject = 'Получен ' . $player['level'] . ' уровень в игре www.moswar.ru';
				break;

			case 'photo_rate':
				$subject = 'Получена Десятка! за фотографию, ' . $player['nickname'];
				break;
		}
		Std::sendMail($player['email'], $subject, $email, 'informer@moswar.ru');
		return true;
	}

	/*
	 * Проверяет, разрешен ли доступ с данного IP-адреса
	 *
	 * @var string $ip - ip-адрес
	 */

	public static function isIpBanned($ip)
    {
		if (Page::$cache->get('ipban') == false) {
			$ips = Page::$sql->getValueSet("select ip from ipban where active = 1 and dt_finished >= curdate()");
			$found = false;
			if ($ips && count($ips))
			foreach ($ips as $i) {
				Page::$cache->set('ipban/' . $i, 1, 600);
				if ($i == $ip || $i == substr($i, 0, strrpos($ip, '.')+1)) {
					$found = true;
				}
			}
			Page::$cache->set('ipban', 1, 600);
			if ($found == true) {
				return true;
			}
			return false;
		}
		if (Page::$cache->get('ipban/' . $ip) == 1 || Page::$cache->get('ipban/' . substr($i, 0, strrpos($ip, '.')+1)) == 1) {
			return true;
		}
		return false;
	}

    /**
     * Фильтр ключевых слов в строке
     *
     * @param string $text
     * @return bool - True - фильтр сработал, False - все чисто
     */
    public function filterBadWords($text)
    {
        $keywords = self::$sql->getRecordSet("SELECT name, pos FROM socialdata WHERE type='mesfilter'");
        $white = array();
        $black = array();
        $black2 = array();
        if ($keywords) {
            foreach ($keywords as $keyword) {
                switch ($keyword['pos']) {
                    case 0: $black[] = $keyword['name']; break;
                    case 1: $white[] = $keyword['name']; break;
                    case 2: $black2[] = $keyword['name']; break;
                }
            }
            $text = str_replace($white, '', strtolower($text));
            if (preg_match('/(' . implode('|', $black) . ')/misu', $text)) {
                return true;
            }
            if (sizeof($black2) > 0) {
                $text = str_replace(array(' ', PHP_EOL), '', $text);
                if (preg_match('/(' . implode('|', $black2) . ')/misu', $text)) {
                    return true;
                }
            }
        }
        return false;
    }

    public static function parseSpecialParams(&$item, $short = false)
    {
        $str1 = $short ? 'sp' : 'special';
        $str2 = $short ? 'n' : 'name';
        $str3 = $short ? 'b' : 'before';
        $str4 = $short ? 'a' : 'after';
        for ($i = 1; $i < 8; $i++) {
            if (stristr($item[$str1 . $i . $str2], '|')) {
                $name = explode('|', $item[$str1 . $i . $str2]);
                $name[1] = explode(';', $name[1]);
                $item[$str1 . $i . $str2] = $name[0];
                $item[$str1 . $i . $str3] = $name[1][0];
                $item[$str1 . $i . $str4] = $name[1][1];
            }
        }
    }
}
?>