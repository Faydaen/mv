var area = '';

function countdown(obj)
{
	var timer = $(obj).attr('timer');
	var s = timer % 60;
	var m = Math.floor(timer / 60) % 60;
	var h = Math.floor(timer / 3600);
	if (s < 10) {
		s = '0' + s;
	}
	if (m < 10) {
		m = '0' + m;
	}
	if (h < 10) {
		h = '0' + h;
	}
	var sTime = h + ':' + m + ':' + s;
	$(obj).text(sTime);
	timer--;
	$(obj).attr('timer', timer);
	
	/* write to title */
	var sTitle = document.title;
	if( /^\s?\[[^\]]*\]/.test(sTitle) ){
		sTitle = sTitle.replace(/^\s?\[([^\]]*)\]/,'['+sTime+']');
	} else {
		sTitle = '['+sTime+'] ' + sTitle;
	}
	document.title = sTitle;

    // bar
    if ($(obj)[0].id != "" && $("#" + $(obj)[0].id + "bar")[0] != null) {
        var bar = $("#" + $(obj)[0].id + "bar");
        bar.css("width", Math.round(($(obj).attr("timer2") - timer) / $(obj).attr("timer2") * 100) + "%");
    }

	if (timer >= 0) {
		setTimeout(function(){countdown(obj);}, 1000);
	} else {
        onTimerCompleteEvent();
		if($(obj).is("td.value") && $(obj).parents("table:first").is("table.process")){
			// if this is table.process
			$(obj).parents("table.process:first").addClass("process-blinking");
		} else {
			var interval = setInterval(function(){
				if("hidden" == $(obj).css("visibility")){
					$(obj).css("visibility","visible");
				} else {
					$(obj).css("visibility","hidden");
				}
			}, "800");
		}
	}
}

var currenthp, maxhp;
function healInit()
{
	currenthp = new Number($('#currenthp').text());
	maxhp = new Number($('#maxhp').text());
	if (currenthp < maxhp) {
		setTimeout(heal, 10000);
	}
}
function heal()
{
	currenthp += maxhp / 180;
	if (currenthp > maxhp) {
		currenthp = maxhp;
	}
	setHP(currenthp);
	if (currenthp < maxhp) {
		setTimeout(heal, 10000);
	}
}
function setHP(hp)
{
	currenthp = hp;
	$("#currenthp").text(Math.round(currenthp));
	$('#playerHpBar').animate({width: Math.round(currenthp / maxhp * 100) + '%'}, 1500);
}

$(document).ready(function()
{
	$('*[timer]').each(function(){
		if ($(this).attr("timer") > 0 && $(this).attr("timer") != '') {
			$(this).show();
			countdown($(this));
		}
	});
	healInit();
	simple_tooltip("*[tooltip=1]","tooltip");
	//$('html,body').animate({scrollTop: 60}, 500);
	$("#smiles img").click(function() {
		emoticon(" :" + $(this).attr("alt") + ": ", $("#smiles").attr("rel"));
		if ($("#smiles").attr("alt") == '1') {
			$("#overtip-smiles").hide();
		}
	});
	setInterval(function(){
		var time = $("#servertime").attr("rel");
		var d = new Date();
		d.setTime((time - (-240) * 60) * 1000);
		var m = d.getUTCMinutes();
		if (m < 10) {
			m = "0" + m;
		}
		var s = d.getUTCSeconds();
		if (s < 10) {
			s = "0" + s;
		}
		$("#servertime").html(d.getUTCHours() + ":" + m + ":" + s);
		time ++;
		$("#servertime").attr("rel", time);
	}, "1000");

    // alert
    $("#alert").show();
});

function postUrl(path, params, method)
{
    var formHtml = '<form action="' + path + '" method="' + method + '" style="display:none;" id="service-form">';
    for(var key in params) {
        formHtml += '<input type="hidden" name="' + key + '" value="' + params[key] + '" />';
    }
    formHtml += '</form>';

    $("#main").append(formHtml);
    $("#service-form").submit();
}

function changePetName(oldName)
{
	var newName = prompt('Введите кличку для вашего животного:', oldName);
	if (newName != null) {
		/*$.post('/player/changepetname/', {name: newName}, function(data){
			document.location.href = '/player/';
		});*/
		postUrl('/player/changepetname/', {action: "changePetName", name: newName}, "post");
	}
}

function input(query, value, path)
{
	var value = prompt(query, value);
	if (value != null) {
		postUrl(path, {param: value}, "post");
	}
}

function showCaptcha(returnUrl)
{
	if ($("#captcha").length > 0) {
		$("#captcha").remove();
	}
	//$("body").append("<div id='captcha' class='overtip' style='background-color: !important; position: absolute; display: block; width: 300px; height: auto; top: 40%; left: 40%; min-width: 300px; min-height: 100px; text-align: center;'><h2>Проверка паспорта</h2><div class='data'>Проезжающий мимо патруль заинтересовался Вами и просит предъявить паспорт:<div id='captcha_inside'><img src='/captcha/&" + Math.random() +  "' /><br /><input type='text' id='captcha_code' name='captcha' value='' /><br /><input type='button' onclick='checkCaptcha(\"" + returnUrl + "\");' value='Показать паспорт' /></div></div></div>");
	$("body").append("<div id='captcha' class='overtip passport-check'><div class='text'><div id='captcha_inside'>Проезжающий мимо патруль заинтересовался Вами:<br />— Честный Майор Дымовский. Проверка документов. <b>Назовите номер вашего паспорта</b>, пожалуйста.</div></div><div class='number'><input type='text' id='captcha_code' name='captcha' value='' /><br /><button class='button' type='button' onclick='checkCaptcha(\"" + returnUrl + "\");'><span class='f'><i class='rl'></i><i class='bl'></i><i class='brc'></i><div class='c'>Назвать номер</div></span></button></div><div class='captcha'><img src='/captcha/&" + Math.random() +  "' /></div></div>");
}

function checkCaptcha(returnUrl)
{
	var code = $('#captcha_code').val();
	$('#captcha_inside').html('<br /><i>Милиционеры смотрят прописку...</i><br />&nbsp;');
	$.post("/captcha/", {action: "check_captcha", code: code}, function(data) {
		if (data == 'ok') {
			$('#captcha_inside').html('<br /><i>Все нормально, можете идти.</i><br />&nbsp;');
			setTimeout(function(){document.location.href=returnUrl;}, "500");
		} else {
			$('#captcha_inside').html('<br /><i>Что-то не так...</i><br />&nbsp;');
			setTimeout(function(){showCaptcha(returnUrl)}, "500");
		}
	});
}

function emoticon(text, elementId)
{
	if (document.getElementById(elementId).createTextRange && document.getElementById(elementId).caretPos) {
		var caretPos = document.getElementById(elementId).caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ? text + ' ' : text;
	} else {
		document.getElementById(elementId).value += text;
	}
	$("#" + elementId).trigger('focus');
}

function simple_tooltip(target_items, name)
{
	$(target_items).each(function(i){
		var content = $(this).attr('title').replace(/\s{2,}/m, '');
		if (content.split('||').length > 1) {
			var arr = content.split('||');
			var title = arr[0];
			if (arr[2]) {
				var desc = arr[1];
				content = arr[2];
			} else {
				content = arr[1];
			}
		}
		if (content.split('|').length > 1) {
			var arr = content.split('|');
			content = '';
			for (j in arr) {
				if (arr[j].replace('	', '').length > 2) content += "<span class='brown'>" + arr[j] + "</span><br />";
			}
			if (desc) {
				content = desc + "<br />" + content;
			}
		}
        var image = "";
		if ($(this).attr('src') && $(this).attr('src').length > 0) {
			image = '<img src="' + $(this).attr('src') + '" />';
		}
        if (image == "") {
            $("body").append("<div class='overtip' style='position: absolute; display: none; max-width: 250px;'><div class='help' id='"+name+i+"'><h2>" + title + "</h2><div class='data'>" + content + "</div></div></div>");
        } else {
            $("body").append("<div class='overtip' style='position: absolute; display: none; max-width: 250px;'><div class='object' id='"+name+i+"'><h2>" + title + "</h2><div class='data'>" + content + "<i class='thumb'>" + image + "</i></div></div></div>");
        }
		$(this).removeAttr("title").mouseover(function(kmouse){
			$("#"+name+i).parents('div.overtip:first').css({opacity:1, display:"none"}).fadeIn(400);
		}).mousemove(function(kmouse){
			$("#"+name+i).parents('div.overtip:first').css({left:kmouse.pageX+15, top:kmouse.pageY+15});
		}).mouseout(function(){
			$("#"+name+i).parents('div.overtip:first').fadeOut(400);
		});
	});
}
function setCookie (name, value)
{
      document.cookie = name + "=" + escape(value);
}

function getCookie(name)
{
	var cookie = " " + document.cookie;
	var search = " " + name + "=";
	var setStr = null;
	var offset = 0;
	var end = 0;
	if (cookie.length > 0) {
		offset = cookie.indexOf(search);
		if (offset != -1) {
			offset += search.length;
			end = cookie.indexOf(";", offset);
			if (end == -1) {
				end = cookie.length;
			}
			setStr = unescape(cookie.substring(offset, end));
		}
	}
	return(setStr);
}

/* форум */

function forumAddVoteOption()
{
	$("input[name='option[]']:last").after('<p><input type="text" name="option[]" /></p>');
}

function forumRemoveVoteOption()
{
	$("input[name='option[]']:gt(1):last").parents('p:first').remove();
}

function forumDeletePost(post, topic)
{
    if (confirm("Удалить сообщение?") == true) {
		$.post("/forum/topic/" + topic + "/", {action: "delete", post: post, topic: topic, ajax: 1}, function(status)
        {
            if (status == "1") {
                $("#post-" + post + "-li").addClass("deleted");
                $("#post-" + post + "-dellink").remove();
            } else {
                alert("Ошибка");
            }
        });
        //postUrl("/forum/topic/" + topic + "/", {action: "delete", post: post, topic: topic}, "post");
    }
}

function forumDeleteTopic(topic, forum)
{
	var result = confirm("Вы уверены, что хотите удалить тему?");
    if (result == true) {
		postUrl("/forum/" + forum + "/", {action: "delete", topic: topic, forum: forum}, "post");
    }
}

function forumCloseTopic(topic)
{
	postUrl("/forum/topic/" + topic + "/", {action: "close", topic: topic}, "post");
}

function forumOpenTopic(topic)
{
	postUrl("/forum/topic/" + topic + "/", {action: "open", topic: topic}, "post");
}

function forumCloseForum(forum)
{
	postUrl("/forum/" + forum + "/", {action: "close", forum: forum}, "post");
}

function forumOpenForum(forum)
{
	postUrl("/forum/" + forum + "/", {action: "open", forum: forum}, "post");
}

function forumMoveTopic(topic, forum)
{
	postUrl("/forum/topic/" + topic + "/", {action: "move topic", topic: topic, forum: forum}, "post");
}

function forumQuote(post)
{
	var text = $(post).find("td:eq(1) > span").html();
	text = text.replace(/<(\/?)(b|i|u)>/gim, "[$1$2]");
	text = text.replace(/<br\s?\/?>/gim, "");
	text = text.replace(/<img src=".*\/([^\.]+)\.gif" align="absmiddle"\s?\/?>/gim, " :$1: ");
	var i = 0;
	while (text.indexOf("<div ", 0) != -1 && i <= 20) {
		text = text.replace(/<div align="center">([^<]+)<\/div>/gim, '[center]$1[/center]');
		text = text.replace(/<div align="right">([^<]+)<\/div>/gim, '[right]$1[/right]');
		text = text.replace(/<div align="left">([^<]+)<\/div>/gim, '[left]$1[/left]');
		text = text.replace(/<div class="quote">([^<]+)<\/div>/gim, '[quote]$1[/quote]');
		i ++;
	}
	var text = "[quote][b]" + $(post).find("td:eq(1) span.user").text() + "[/b] ([i]" + $(post).find("td:eq(1) div.date span:first").text() + "[/i])\r\n" + text + "[/quote]\r\n";
	emoticon(text, 'posttext');
}

function macdonaldsLeave()
{
	var result = confirm('Вы уверены, что хотите бросить работу? Вы не получите зарплату.');
	if (result == true) {
		postUrl('/shaurburgers/', {action: 'leave'}, 'post');
	}
}

function alleyPatrolLeave()
{
	var result = confirm('Вы уверены, что хотите бросить патрулирование? Вы не получите зарплату.');
	if (result == true) {
		postUrl('/alley/', {action: 'leave'}, 'post');
	}
}

/* аЙфон */

function phoneDeleteMessages(type)
{
	var result = confirm('Вы уверены, что хотите удалить все сообщения?');
	if (result == true) {
		if (type == "outbox") {
			type = "outbox/";
		}
		postUrl('/phone/messages/' + type, {action: "delete"}, 'post');
	}
}

function phoneConfirmDeleteContact(nickname, id, type)
{
    var result = confirm("Вы уверены, что хотите удалить из своих контактов игрока " + nickname + "?");
    if (result == true) {
		postUrl("/phone/contacts/", {action:"delete", id:id, nickname:nickname, type:type}, "post");
    }
}

function phoneDeleteLogs()
{
	var result = confirm('Вы уверены, что хотите удалить все логи?');
	if (result == true) {
		postUrl('/phone/logs/', {action: "delete"}, 'post');
	}
}

function phoneComplainMessage(id)
{
	var result = confirm('Вы уверены, что хотите отправить жалобу на это сообщение? Сообщение будет автоматически удалено.');
	if (result == true) {
		postUrl('/phone/messages/', {action: "complain", id: id}, 'post');
	}
}

/* метро */

function metroWork()
{
	postUrl("/metro/", {action: "work"}, "post");
}

function metroDig()
{
	postUrl("/metro/", {action: "dig"}, "post");
}

function metroLeave()
{
	var result = confirm('Вы уверены, что хотите выбраться наружу? Вы ничего не получите.');
	if (result == true) {
		postUrl('/metro/', {action: 'leave'}, 'post');
	}
}

function metroSearchRat(playerId)
{
    postUrl("/metro/search-rat/", {player: playerId}, "post");
}

function metroLeave2()
{
	postUrl('/metro/', {action: 'leave'}, 'post');
}

function metroAttackRat(playerId)
{
    postUrl("/alley/attack-npc/1/", {player: playerId}, "post");
}

/* player */

function playerSellPet(id)
{
	var result = confirm('Вы уверены, что хотите продать питомца?');
	if (result == true) {
		postUrl("/shop/section/zoo/sell/" + id + "/", {}, "get");
	}
}

/* Кланы */

// mo to dip int
function clanLeave() {
	var result = confirm('Вы уверены, что хотите покинуть клан?');
	if (result == true) {
		postUrl("/clan/profile/", {action: "leave"}, "post");
	}
}

// mo to dip int
function clanAccept(player_id) {
	postUrl("/clan/profile/", {action: "accept", player: player_id}, "post");
}

// mo to dip int
function clanDrop(player_id)
{
    if (window.confirm("Вы уверены, что хотите исключить этого игрока из клана?")) {
        postUrl("/clan/profile/", {action: "drop", player: player_id}, "post");
    }
}

// mo to dip int
function clanRefuse(player_id) {
	postUrl("/clan/profile/", {action: "refuse", player: player_id}, "post");
}

// delete
function clanDissolve() {
	var result = confirm('Вы уверены, что хотите распустить клан? Все имущество клана будет потеряно.');
	if (result == true) {
		postUrl("/clan/profile/", {action: "dissolve"}, "post");
	}
}


function clanDiplomacyExt(clanId, diplomacyType)
{
    switch (diplomacyType) {
        case "apply":
            confirmText = "Вы уверены, что хотите подать заявку на вступление в клан? При отказе деньги не возвращаются.";
            break;

        case "apply_cancel":
            confirmText = "Вы уверены, что хотите отменить заявку на вступление в клан? Деньги не возвращаются.";
            break;

        case "union_propose":
            confirmText = "Вы уверены, что хотите предложить союз? При отказе деньги не возвращаются.";
            break;

        case "union_propose_cancel":
            confirmText = "Вы уверены, что хотите отменить предложение заключить союз? Деньги за предложение не возвращаются.";
            break;

        case "attack":
            confirmText = "Вы уверены, что хотите напасть на этот клан?";
            break;

        default:
            confirmText = "Вы уверены?";
            break;
    }
    if (confirm(confirmText) == true) {
		postUrl("/clan/" + clanId + "/", {action: diplomacyType}, "post");
	}
}

function clanDiplomacyInt(diplomacyId, diplomacyType)
{
    switch (diplomacyType) {
        case "canceltitle":
            confirmText = "Вы уверены, что хотите капитулировать? Победа в войне со всеми вытекающими последствиями будет отдана врагу.";
            break;

        default:
            confirmText = "Вы уверены?";
            break;
    }
    if (confirm(confirmText) == true) {
		postUrl("/clan/profile/", {action: diplomacyType, diplomacy: diplomacyId}, "post");
	}
}

function clanInternalAction(action, param)
{
    switch (action) {
        case "canceltitle":
            confirmText = "Вы уверены, что хотите отказаться от должности?";
            url = "team/canceltitle/";
            break;

        default:
            confirmText = "Вы уверены?";
            break;
    }
    if (confirm(confirmText) == true) {
		postUrl("/clan/profile/" + url, {action:action, param:param}, "post");
	}
}

function clanWarehouseTake(inventoryId, itemCode)
{
    $.post("/clan/profile/warehouse/take/", {inventory: inventoryId, code: itemCode}, function(data) {
		if (data == 1) {
            document.location.href = "/clan/profile/warehouse/";
        }
	});
}

function clanWarehousePut(inventoryId, itemCode)
{
    $.post("/clan/profile/warehouse/put/", {inventory: inventoryId, code: itemCode}, function(data) {
		if (data == 1) {
            document.location.href = "/clan/profile/warehouse/";
        } else if (data == -1) {
            alert("Склад переполнен.");
        }
	});
}

function clanShowWarUserLogs()
{
    if($('#clan-warstat1-table tr.user-logs td').is(':visible')) {
        $('#clan-warstat1-table tr.user-logs').hide();
    } else {
        $('#clan-warstat1-table tr.user-logs').show();
    }
}

/* common */

var showHelpTips = function()
{
    $("#overtip-help-alley").show("normal");
    if(!jQuery.browser.msie)$("#background").show();
}

var closeHelpTips = function(obj)
{
    $(obj).parents('div.overtip:first').hide('fast');
    $('#background').hide();
    setCookie("hideHelpTips","1");
}

function onTimerCompleteEvent()
{
    switch (area) {
        case "metro":
            $("#kopaem").hide();
            if ($.ajax({url:"/metro/myrat/", async:false}).responseText == "1") {
                $("#welcome-no-rat").hide();
                $("#content-no-rat").hide();
                $("#welcome-rat").show();
            } else {
                $("#ore_chance").html($.ajax({url:"/metro/myorechance/", async:false}).responseText + "%");
            }
            $("#vykopali").show();
            break;

        case "metro_rat":
            $("#ratsearch").hide();
            var ratLevel = $.ajax({url:"/metro/myrat/", async:false}).responseText;
            if (ratLevel == "0") {
                $("#ratnotfound").show();
            } else {
                $("#welcome-no-rat").hide();
                $("#content-no-rat").hide();
                $("#ratlevel").html(ratLevel);
                $("#welcome-rat").show();
            }
            break;

        case "factory_petrik":
            $("#factory_petrik_1").hide();
            $("#factory_petrik_2").show();
            break;

        case "trainer_vip":
            $("#trainer_vip_1").hide();
            $("#trainer_vip_2").show();
            break;
    }
}

/*
        $.post($("#" + formId)[0].action, $("#" + formId).serialize(), function(status)
        {
            if (status == "1") {
                eval(onSuccess + "();");
            }
        });
*/

// отправка формы
function sendForm(formId, formCheckFunction)
{
    var checked;
    eval("checked = " + formCheckFunction + "();");
    if (checked) {
        $("#" + formId)[0].submit();
    }
}

/* Shop */

// проверка формы дарения подарка
function checkPresentForm()
{
    if ($("#present-form-playerid").val() == "") {
        if (!$("#to-me")[0].checked) {
            player = $.trim($("#present-form-player").val());
            if (player == "") {
                $("#present-form div.report").show();
                $("#present-form div.error").html("Введите имя игрока");
                return false;
            }
            if ($.ajax({url:"/shop/playerexists/" + player + "/", async:false}).responseText == "0") {
                $("#present-form div.report").show();
                $("#present-form div.error").html("Игрок <b>" + player + "</b> не найден");
                return false;
            }
        }
    } else {
        if ($.ajax({url:"/shop/playeridexists/" + $("#present-form-playerid").val() + "/", async:false}).responseText == "0") {
            $("#present-form div.report").show();
            $("#present-form div.error").html("Игрок <b>" + player + "</b> не найден");
            return false;
        }
    }
    return true;
}

// отображение формы дарения подарка
function showPresentForm(itemId, itemName)
{
    $("#present-form")[0].action = "/shop/section/gifts/buy/" + itemId + "/";
    $("#present-form-player").val("");
    $("#present-form-comment").val("");
    $("#present-form-private")[0].checked = false;
    $("#present-form-anonimous")[0].checked = false;
    $("#present-form-present").html(itemName);
    $("#present-form div.report").hide();
    $("#present-panel").show();
	$("#present-panel").css('top', $(document).scrollTop()+($(window).height() / 2)-($("#present-panel").height()/2)-200); /* 200 = $('div.column-right').offset().top */
}

/* fight */

function fightShowLog(element)
{
    if (!element) {
        element = $("#fight-log li:hidden:last");
    }
    element.slideDown("normal");
    lifes = element.attr("rel").split(":");

    fighter1_life = lifes[0].split("/");
    $("#fighter1-life").html(Math.max(fighter1_life[0], 0) + '/' + fighter1_life[1]);
    $("#fighter1-life").parent().find("div.percent").animate( {width: Math.ceil(100 * fighter1_life[0] / fighter1_life[1]) + "%"}, 1500 );

    fighter2_life = lifes[1].split("/");
    $("#fighter2-life").html(Math.max(fighter2_life[0], 0) + '/' + fighter2_life[1]);
    $("#fighter2-life").parent().find("div.percent").animate( {width: Math.ceil(100 * fighter2_life[0] / fighter2_life[1]) + "%"}, 1500 );

    if (lifes[2] != "") {
        pet1_life = lifes[2].split("/");
        $("#pet0-life").html(Math.max(pet1_life[0], 0) + '/' + pet1_life[1]);
        $("#pet0-life").parent().parent().find("div.percent").animate( {width: Math.ceil(100 * pet1_life[0] / pet1_life[1]) + "%"}, 1500 );
    }

    if (lifes[3] != "") {
        pet2_life = lifes[3].split("/");
        $("#pet1-life").html(Math.max(pet2_life[0], 0) + '/' + pet2_life[1]);
        $("#pet1-life").parent().parent().find("div.percent").animate( {width: Math.ceil(100 * pet2_life[0] / pet2_life[1]) + "%"}, 1500 );
    }

    if (interactive && player > 0) {
        if (player == 1) {
            setHP(fighter1_life[0]);
        } else {
            setHP(fighter2_life[0]);
        }
    }
}

function fightTimer()
{
    $("#time-left").html(timeleft);
    timeleft--;
    if(timeleft < 0) {
        var element = $("#fight-log li:hidden:last");
        timeleft = 2;
        var lifes;
        var fighter1_life, fighter2_life;
        if(1 == $("#fight-log li").index(element)) {
            timeleft = 2;
            $("#timer-block").hide();
            fightShowLog(element);
        } else if($("#fight-log li").index(element) == -1) {
            $('#timer-block').hide();
            window.clearInterval(timer);
            $("#controls-play").addClass("disabled");
            $("#controls-forward").addClass("disabled");
        } else if($("#fight-log li").index(element) == 0) {
            //fightShowLog(element);
            element.slideDown("normal");
            $('#timer-block').hide();
            window.clearInterval(timer);
            $("#controls-play").addClass("disabled");
            $("#controls-forward").addClass("disabled");
        } else {
            fightShowLog(element);
        }
    }
}

function fightGo()
{
    $(document).ready(function(){
        if(interactive) {
            $("#controls-play").addClass("disabled");
            fightShowLog();
            timer = window.setInterval("fightTimer()", 1000);
        } else {
            fightForward();
        }
    });
}

function fightBack()
{
    if ($("#controls-back").hasClass("disabled")) {
        return;
    }

    $('#timer-block').hide();
    window.clearInterval(timer);

    $("#fight-log li").hide();
    $($("#fight-log li")[$("#fight-log li").length - 1]).show();

    $("#controls-back").addClass("disabled");
    $("#controls-play").removeClass("disabled");
    $("#controls-forward").removeClass("disabled");

    lifes = $($('#fight-log > li[rel]')[$('#fight-log > li[rel]').length - 1]).attr("rel").split(":");

    fighter1_life = lifes[0].split("/");
    $("#fighter1-life").html(Math.max(fighter1_life[0], 0) + '/' + fighter1_life[1]);
    $("#fighter1-life").parent().find("div.percent").animate( {width: Math.ceil(100 * Math.max(fighter1_life[0], 0) / fighter1_life[1]) + "%"}, 1500 );

    fighter2_life = lifes[1].split("/");
    $("#fighter2-life").html(Math.max(fighter2_life[0], 0) + '/' + fighter2_life[1]);
    $("#fighter2-life").parent().find("div.percent").animate( {width: Math.ceil(100 * Math.max(fighter2_life[0], 0) / fighter2_life[1]) + "%"}, 1500 );

    if (lifes[2] != "") {
        pet1_life = lifes[2].split("/");
        $("#pet0-life").html(Math.max(pet1_life[0], 0) + '/' + pet1_life[1]);
        $("#pet0-life").parent().parent().find("div.percent").animate( {width: Math.ceil(100 * Math.max(pet1_life[0], 0) / pet1_life[1]) + "%"}, 1500 );
    }

    if (lifes[3] != "") {
        pet2_life = lifes[3].split("/");
        $("#pet1-life").html(Math.max(pet2_life[0], 0) + '/' + pet2_life[1]);
        $("#pet1-life").parent().parent().find("div.percent").animate( {width: Math.ceil(100 * Math.max(pet2_life[0], 0) / pet2_life[1]) + "%"}, 1500 );
    }
}

function fightPlay()
{
    if ($("#controls-play").hasClass("disabled")) {
        return;
    }

    $("#controls-back").removeClass("disabled");
    $("#controls-play").addClass("disabled");
    $("#controls-forward").removeClass("disabled");

    timeleft = 2;
    fightShowLog();
    timer = window.setInterval("fightTimer()", 1000);
}

function fightForward()
{
    if ($("#controls-forward").hasClass("disabled")) {
        return;
    }

    $("#controls-back").removeClass("disabled");
    $("#controls-play").addClass("disabled");
    $("#controls-forward").addClass("disabled");

    $("#fight-log li").show();
    $('#timer-block').hide();
    lifes = $('#fight-log > li[rel]').attr("rel").split(":");

    fighter1_life = lifes[0].split("/");
    $("#fighter1-life").html(Math.max(fighter1_life[0], 0) + '/' + fighter1_life[1]);
    $("#fighter1-life").parent().find("div.percent").animate( {width: Math.ceil(100 * Math.max(fighter1_life[0], 0) / fighter1_life[1]) + "%"}, 1500 );

    fighter2_life = lifes[1].split("/");
    $("#fighter2-life").html(Math.max(fighter2_life[0], 0) + '/' + fighter2_life[1]);
    $("#fighter2-life").parent().find("div.percent").animate( {width: Math.ceil(100 * Math.max(fighter2_life[0], 0) / fighter2_life[1]) + "%"}, 1500 );

    if (lifes[2] != "") {
        pet1_life = lifes[2].split("/");
        $("#pet0-life").html(Math.max(pet1_life[0], 0) + '/' + pet1_life[1]);
        $("#pet0-life").parent().parent().find("div.percent").animate( {width: Math.ceil(100 * Math.max(pet1_life[0], 0) / pet1_life[1]) + "%"}, 1500 );
    }

    if (lifes[3] != "") {
        pet2_life = lifes[3].split("/");
        $("#pet1-life").html(Math.max(pet2_life[0], 0) + '/' + pet2_life[1]);
        $("#pet1-life").parent().parent().find("div.percent").animate( {width: Math.ceil(100 * Math.max(pet2_life[0], 0) / pet2_life[1]) + "%"}, 1500 );
    }
}

/* group fight */

function groupFightPlayerDie(id,hp)
{
    if(hp <= 0) {
        $("#fighter"+id+"-life").parents("li:first").addClass("dead")
    }
}

function groupFightShowLog(element)
{
    return;
    if (!element) {
        element = $("#fight-log li:hidden:last");
    }
    element.slideDown("normal");
    if (element.attr("rel")){
        var players = element.attr("rel").split(":");
        for (var i=0; i<players.length; i++) {
            var lifes = players[i].split("/");
            var hp = lifes[1];
            var id = lifes[0];
            $("#fighter"+id+"-life").html(hp + "/" + lifes[2]);
            $("#fighter"+id+"-life").parent().find("span.percent").animate( {width: Math.ceil(100*hp/lifes[2]) + "%"}, 1000, false, groupFightPlayerDie(id, hp));
        }
    }
    element.next().find('div.text').slideToggle(); /* спрятать лог предыдущего хода */
}

function groupFightTimer()
{
    $("#time-left").html(timeleft);
    timeleft--;
    if (timeleft == -1) {
        document.location.href = document.location.href;
    }
}

function groupFigthBindCick()
{
    $("#fightGroupForm input[name=target]").bind("click", function()
    {
        if (this.id.indexOf("attack") >= 0) {
            $("#fightGroupForm label").removeClass("selected");
            var username = $(this).parents("li:first").find("span.user").text(); // имя игрока
            $("#fight-button-text").html("Атаковать: "+username);
            $(this).parents("label:first").addClass("selected");
            $("#actionfield").val('attack');
        } else if (this.id.indexOf("defence") >=0 ) {
            $("#fightGroupForm label").removeClass("selected");
            var username = $(this).parents("li:first").find("span.user").text(); // имя игрока
            $("#fight-button-text").html("Защитить: "+username);
            $(this).parents("label:first").addClass("selected");
            $("#actionfield").val('defence');
        } else if (this.id.indexOf("use") >= 0 && $(this).parents("li:first").hasClass("filled")) {
            $("#fightGroupForm label").removeClass("selected");
            var itemname = $(this).parents("li:first").find("img").attr("title"); // название приема или предмета
            $("#fight-button-text").html("Использовать: "+itemname);
            $(this).parents("label:first").addClass("selected");
            $("#actionfield").val('useitem');
        }
    });
}

function groupFightMakeStep()
{
	$("button[type=submit]").addClass('disabled');
	$("button[type=submit]").parents("div.center:first").find("div.hint").hide();
	$.post("/fight/", {action: $('#actionfield').val(), item: $("input:radio[name=item]:checked").val(), target: $("input:radio[name=target]:checked").val(), json: 1}, function(data) {
		$("button[type=submit]").hide()
		$("div.waiting").show();
	});
}

/* photos */

function photoAction(photo) {
	var action = $('#photoAction option:selected').val();
	if (action == '---') {
		return;
	}
	var reason = "";
	if (action == 'cancel') {
		reason = $('#photoAction option:selected').text();
		if (reason == "Другое") {
			reason = prompt("Укажите причину:");
			if (reason == null || reason == "") {
				alert("Необходимо указать причину.");
				return;
			}
		}
	}
	postUrl("/photos/", {action: action, photo: photo, reason: reason}, "post");
}

function photoRate(photo, value, type) {
	postUrl("/photos/", {action: "rate", photo: photo, value: value, type: type}, "post");
}

function photoDelete(photo)
{
	if (confirm("Вы уверены, что хотите удалить фотографию?") == true) {
		postUrl("/photos/", {action: "delete", photo: photo}, "post");
	}
}

function photoAccept(photo)
{
	postUrl("/photos/", {action: "accept", photo: photo}, "post");
}

function photoCancel(photo)
{
	postUrl("/photos/", {action: "cancel", photo: photo}, "post");
}

function photoSetInProfile(photo)
{
	postUrl("/photos/", {action: "set in profile", photo: photo}, "post");
}

/* персонаж */

function loadPlayerComments(playerId, offset)
{
    $.get("/player/" + playerId + "/history/" + offset + "/", {}, function(data)
    {
        if (data.length > 0) {
            html = "<table class='datatable'><tr><td class='d'><b>Дата</b></td><td class='m'><b>Модератор</b></td><td class='a'><b>Действие</b></td><td><b>Период</b></td><td><b>Комментарий</b></td></tr>";
            for (i = 0; i < (data.length - 1); i++) {
                html += "<tr " + (i % 2 ? "class='odd'" : "") + "><td>" + data[i].d + "</td><td><a href='/player/" + data[i].id + "/'>" + data[i].nm + "</a></td><td>" + data[i].a + "</td><td>" + data[i].p + "</td><td>" + data[i].c + "</td></tr>";
            }
            html += "</table>";
            total = data[data.length - 1].id;
            if (total > 50) {
                pages = Math.floor(total / 20);
                if (pages != total / 20) {
                    pages++;
                }
                html += "<p>Страницы: ";
                for (i = 0; i < pages; i++) {
                    offset2 = i * 20;
                    if (offset2 == offset) {
                        html += "&nbsp;<b>" + (i + 1) + "</b>&nbsp;";
                    } else {
                        html += "&nbsp;<a href='javascript:void(0);' onclick='loadPlayerComments(" + playerId + ", " + offset2 + ");'>" + (i + 1) + "</a>&nbsp;";
                    }
                }
                html += "</p>";
            }
            $("#pers-admin2-block").html(html);
        }
    }, "json");
}

/* factory */

// не используется
function factoryMf(inventoryId)
{
    document.location.href = "/factory/mf-item/" + inventoryId + "/";
}

/* trainer */

var stats = ["health","strength","dexterity","resistance","intuition","attention","charism"];
var stat_upgrade_time = 10; /* время прокачки 1 стата */

function trainerCost(statmy, stataverage, stat)
{
    var k = [2.5, 2.9, 2.6, 2.8, 2.4, 2.2, 2.7];
    var minK = 2.6;

    var statK = k[stat] / minK;
   

    var ratio = Number(statmy) / Number(stataverage);
    var cost = (Math.pow(2, ratio) - 1) * (Math.pow(3, ratio) - 1) * 3.3 * statK;
    cost *= 10; // в петриках
	if (cost<10) cost=10;
    return cost;
}

function trainerCostAdd(currentstat, needstat, averagestat, stat)
{
    var sum = 0;
    for (var i = currentstat + 1; i <= needstat; i++) {
        sum += trainerCost(i, averagestat, stat);
    }
    return sum;
}


function trainerCalculatorCalculate()
{
    var stats_amount_sum = 0;
    var stats_cost_sum = 0;

    var tr;
    var curstat;
    var needstat;
    var mystat;
    var stat_cost;
    var averagestat;
	//var anabolics =  Number($("#trainer-anabolics-total").text());
	var submitbutton = $("#calculator button.button");

    for (var i = 0, j = stats.length; i < j; i++) {
        tr = $("#calculator").find("tr[rel=" + stats[i] + "]");
        curstat = Number(tr.find("td.my span.number").html()) || 0;
        needstat = Number(tr.find("input[type=text]").val()) || 0;
        if (needstat < 0) {
            needstat = 0;
        }
        mystat = curstat + needstat;

        /* сумма статов и время */
        stats_amount_sum += needstat;

        /* звездочки преимущества */
        averagestat = Number(tr.find("td.average span.number").text());

        /* сумма стоимости */
        stat_cost = trainerCostAdd(curstat, mystat, averagestat, i);

        stats_cost_sum += Math.floor(stat_cost * 10) / 10;

        $("#calculator").find("tr[rel=" + stats[i] + "]").find("td.cost span.number").html(Math.floor(stat_cost * 10) / 10);

        var stars = tr.find("td.advantage span.percent");
        if (averagestat > 0) {
            var stats_ratio = mystat / averagestat;
            if (stats_ratio <= 1.2) {
                stars.css("width", "0%");
            } else if (stats_ratio <= 1.4) {
                stars.css("width", "20%");
            } else if (stats_ratio <= 1.6) {
                stars.css("width", "40%");
            } else if (stats_ratio <= 1.8) {
                stars.css("width", "60%");
            } else if (stats_ratio <= 2) {
                stars.css("width", "80%");
            } else if (stats_ratio > 2) {
                stars.css("width", "100%");
            }
        }
		/* дизейбл кнопок + и - */
		if (needstat == 0) { 
			tr.find("i.minus-icon").addClass("minus-icon-disabled");
		} else {
			tr.find("i.minus-icon").removeClass("minus-icon-disabled");
		}
		if (needstat == 99) { 
			tr.find("i.plus-icon").addClass("plus-icon-disabled");
		} else {
			tr.find("i.plus-icon").removeClass("plus-icon-disabled");
		}
    }
    $("#calculator").find("tr[rel=total] td.my").find("span.number").html(stats_amount_sum);
    $("#calculator").find("tr[rel=total] td.my").find("span.time").html(stats_amount_sum * stat_upgrade_time);

    $("#stats_upgrade_cost").html(formatNumber(Math.ceil(stats_cost_sum), 0, "", ","));

    if ($("#trainer-anabolics-deficit-checkbox")[0] != null) {
        //if ((myAnabolics2 + myAnabolics) < Math.ceil(stats_cost_sum) && $("#trainer-anabolics-deficit-checkbox")[0].checked) {
        if ((myAnabolics2 + myAnabolics) < Math.ceil(stats_cost_sum)) {
            $("#trainer-anabolics-deficit").hide();
            $("#trainer-anabolics-deficit2").show();

            submitbutton.addClass("disabled");
            submitbutton.attr("disabled", true);
        } else if ((myAnabolics2 + myAnabolics) >= Math.ceil(stats_cost_sum) && $("#trainer-anabolics-deficit-checkbox")[0].checked) {
            $("#trainer-anabolics-deficit2").hide();
            $("#trainer-anabolics-deficit").show();

            if ($("#trainer-anabolics-deficit-checkbox").is(":checked")) {
                submitbutton.removeClass("disabled");
                submitbutton.attr("disabled", false);
            } else {
                submitbutton.addClass("disabled");
                submitbutton.attr("disabled", true);
            }
        } else if (myAnabolics < Math.ceil(stats_cost_sum)) {
            $("#trainer-anabolics-deficit2").hide();
            $("#trainer-anabolics-deficit").show();

            submitbutton.addClass("disabled");
            submitbutton.attr("disabled", true);
        } else {
            $("#trainer-anabolics-deficit").hide();
            $("#trainer-anabolics-deficit2").hide();

            submitbutton.removeClass("disabled");
            submitbutton.attr("disabled", false);
        }
    }
}

function trainerCalculatorInit()
{
    for (var i = 0, j = stats.length; i < j; i++){
        $("#calculator").find("tr[rel=" + stats[i] + "]").find("td.my span.number").html(stats_my[i]);
        $("#calculator").find("tr[rel=" + stats[i] + "]").find("td.average span.number").html(stats_average[i]);
        $("#calculator").find("tr[rel=" + stats[i] + "]").find("input[type=text]").bind("keyup", function()
        {
            trainerCalculatorCalculate();
        });
		$("#calculator").find("tr[rel="+stats[i]+"]").find("i.plus-icon").bind("click",function(){
			var input = $(this).parents("b:first").find("input[type=text]");
			var newvalue = Number(input.val())+1;
			if(newvalue>=0 && newvalue<=99){
				input.val(newvalue);
				trainerCalculatorCalculate();
			}
		});
		$("#calculator").find("tr[rel="+stats[i]+"]").find("i.minus-icon").bind("click",function(){
			var input = $(this).parents("b:first").find("input[type=text]");
			var newvalue = Number(input.val())-1;
			if(newvalue>=0 && newvalue<=99){
				input.val(newvalue);
				trainerCalculatorCalculate();
			}
		});
		$("#trainer-anabolics-deficit-checkbox").bind("click", function()
        {
			trainerCalculatorCalculate();
		})
        trainerCalculatorCalculate();
    }
}

function trainerAnabolicsPrepareCount()
{
	var i = Number($("#trainer-personal-anabolics-number").val());
    $("#count-span").html(i * 10);
	$("#trainer-personal-anabolics-petric").html(i);
	$("#trainer-personal-anabolics-med").html(i);
}

function trainerAnabolicsPrepareInit()
{
	$("#trainer-personal-anabolics-number").bind("keyup", function()
    {
		trainerAnabolicsPrepareCount();
	});
}

function socialProfileFormInit()
{
    $("#city-tr").hide();
    $("#metro-tr").hide();
    if ($("#country-select").val() != "") {
        $("#city-tr").show();
    }
    if ($("#city-select").val() != "") {
        $("#metro-tr").show();
    }
}

function socialProfileFormShowHide()
{
    if ($("#city-select").val() == "" || $("#metro-select")[0].options.length == 1) {
        $("#metro-tr").hide();
    }
    if ($("#country-select").val() == "" || $("#city-select")[0].options.length == 1) {
        $("#city-tr").hide();
    }
}

function socialProfileLoadCities()
{
    $("#metro-tr").hide();
    $("#city-tr").hide();
    if ($("#country-select").val() != "") {
        $.ajax({url:"/settings/load-items/city/" + $("#country-select").val() + "/", async:false, success:function(data){
            if (data.length > 0) {
                $("#city-select").html("");
                $("#city-select").append('<option value=""> - выберите - </option>');
                for (i = 0; i < data.length; i++) {
                    $("#city-select").append('<option value="' + data[i].id + '">' + data[i].nm + '</option>');
                }
                $("#city-tr").show();
            }
        }, dataType:"json"});
    }
}

function socialProfileLoadMetros()
{
    $("#metro-tr").hide();
    if ($("#city-select").val() != "") {
        $.ajax({url:"/settings/load-items/metro/" + $("#city-select").val() + "/", async:false, success:function(data){
            if (data.length > 0) {
                $("#metro-select").html("");
                $("#metro-select").append('<option value=""> - выберите - </option>');
                for (i = 0; i < data.length; i++) {
                    $("#metro-select").append('<option value="' + data[i].id + '">' + data[i].nm + '</option>');
                }
                $("#metro-tr").show();
            }
        }, dataType:"json"});
    }
}

function clanTeamCalcCost()
{
    var cost = 0;
    if ($("select[name=founder]").val() != curFounderId) {
        cost += 50000;
    }
    if ($("select[name=adviser]").val() != curAdviserId) {
        cost += 5000;
    }
    if ($("select[name=money]").val() != curMoneyId) {
        cost += 5000;
    }
    if ($("select[name=forum]").val() != curForumId) {
        cost += 5000;
    }
    if ($("select[name=diplomat]").val() != curDiplomatId) {
        cost += 5000;
    }
    if ($("select[name=people]").val() != curPeopleId) {
        cost += 5000;
    }
    $("#cur-tugriks").html(formatNumber(cost,0,".",",") + "<i></i>");
    
    if (cost > 0) {
        $("#button-price").show();
    } else {
        $("#button-price").hide();
    }
    if (cost > clanMoney || cost == 0) {
        $("#roles-submit").addClass("disabled");
        $("#roles-submit").attr("disabled", true);
        if (cost > clanMoney) {
            $("#no-money").show();
        }
    } else {
        $("#roles-submit").removeClass("disabled");
        $("#roles-submit").attr("disabled", false);
        $("#no-money").hide();
    }
}

function formatNumber(number, decimals, decimalsPoint, thousandsSeparator)
{
	number = Number(number) || 0;
    if (decimals > 0) {
        number = Math.round(number * (decimals * 10)) / (decimals * 10);
    }
    var a = Math.floor(number);
    var b = number - a;
    a = a + ""; // перевод числа в строку
    var a2 = "";
    var j = 0;
    for (var i = a.length - 1; i >= 0; i--) {
        a2 += a.charAt(j);
        j++;
        if (i % 3 == 0 && i != 0) {
            a2 += thousandsSeparator;
        }
    }
    if (decimals > 0) {
        a2 = a2 + decimalsPoint + b;
    }
    return a2;
}

function alleyNaperstkiPlay(cells)
{
    $.get("/alley/naperstki/play/" + cells + "/", {}, function(data)
    {
        if (data != "") {
            $("#naperstki-step1").hide();
            $("#naperstki-step3").hide();
            $("#naperstki-step2-cells" + (data.c == 3 ? 9 : 3)).hide();
            $("#naperstki-step2-cells" + data.c).show();
            desk = "";
            for (var i = 0; i < data.c; i++) {
                if (i == 3 || i == 6) {
                    desk += "<br />";
                }
                switch (data.d[i]) {
                    case "0":
                        desk += '<i id="thimble' + i + '" class="icon thimble-closed-active" onclick="alleyNaperstkiGuess(' + i + ');"></i>';
                        break;
                    case "1":
                        desk += '<i id="thimble' + i + '" class="icon thimble-closed"></i>';
                        break;
                    case "2":
                        desk += '<i id="thimble' + i + '" class="icon thimble-guessed"></i>';
                        break;
                    case "3":
                        desk += '<i id="thimble' + i + '" class="icon thimble-empty"></i>';
                        break;
                }
            }
            $("#naperstki-step2 .thimbles").html(desk);
            $("#naperstki-ruda").html(data.r + "<i></i>");
            $("#naperstki-left").html(data.c == 3 ? 1 - data.g : 3 - data.g);
            $("#naperstki-step2").show();

            updatePlayerBlockMoney(cells == 3 ? 500 : (cells == 9 ? 1500 : 0), "-");
        }
    }, "json");
}

function alleyNaperstkiGuess(cell)
{
    $.get("/alley/naperstki/guess/" + cell + "/", {}, function(data)
    {
        if (data != "") {
            if (data.left == 0) {
                $("#naperstki-step2 .thimbles i").removeClass("thimble-closed-active").addClass("thimble-closed");
                $("#naperstki-step3").show();
            }
            $("#naperstki-left").html(data.left);
            $("#naperstki-ruda").html(data.ruda + "<i></i>");
            $("#thimble" + cell).removeClass("thimble-closed");
            if (data.result == "1") {
                $("#thimble" + cell).addClass("thimble-guessed");
            } else {
                $("#thimble" + cell).addClass("thimble-empty");
            }
        }
    }, "json");
}

function alleyNaperstkiLeave()
{
    $.get("/alley/naperstki/leave/", {}, function(data){}, "json");
    $("#naperstki").hide();
}

function updatePlayerBlockMoney(sum, op)
{
    var money = $("#personal .tugriki-block").attr("title");
    money = money.split(':');
    money = parseInt($.trim(money[1]));
    switch (op) {
        case "+": money += sum; break;
        case "-": money -= sum; break;
    }
    $("#personal .tugriki-block").attr("title", "Монет: " + money);
    $("#personal .tugriki-block").html('<b class="tugriki"></b><br>' + formatNumber(money, 0, "", ","));
}