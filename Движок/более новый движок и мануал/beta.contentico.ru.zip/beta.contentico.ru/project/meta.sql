CREATE TABLE `metaobject` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `code` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `versions` tinyint(3) unsigned NOT NULL default 0,
  `logs` tinyint(1) unsigned default 0,
  PRIMARY KEY  (`id`),
  UNIQUE `uq__metaobject__code` (`code`)
) ENGINE=InnoDb DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;

CREATE TABLE `metaattribute` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `metaobject` int(10) unsigned NOT NULL,
  `code` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `type` tinyint(3) unsigned NOT NULL,
  `typeparam` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL default '',
  `role` tinyint(3) unsigned NOT NULL default 3,
  PRIMARY KEY  (`id`),
  UNIQUE `uq__metaattribute__metaobject` (`metaobject`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;

CREATE TABLE `metaview` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `metaobject` int(10) unsigned NOT NULL,
  `code` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `type` tinyint(3) unsigned NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL default '',
  `treemetaobject` int(10) unsigned NOT NULL default 0,
  `template` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `templaterow` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `ix__metaview__metaobject` (`metaobject`),
  UNIQUE `uq__metaview__code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;

CREATE TABLE `metaviewfield` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `metaview` int(10) unsigned NOT NULL,
  `metaattribute` int(10) unsigned NOT NULL,
  `uie` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL default '',
  `uieparams` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL default '',
  `defaultvalue` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL default '',
  `required` tinyint(1) unsigned NOT NULL default 0,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL default '',
  `hint` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL default '',
  `unit` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL default '',
  `mask` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL default '',
  `group` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL default '',
  `pos` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `ix__metaviewfield__metaview` (`metaview`)
) ENGINE=InnoDb DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;

CREATE TABLE `metaviewcondition` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `metaview` int(10) unsigned NOT NULL,
  `metaattribute` int(10) unsigned NOT NULL,
  `operation` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `value` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL default '',
  `sql` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `ix__metaviewcondition__metaview` (`metaview`)
) ENGINE=InnoDb DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;

CREATE TABLE `metarelation` (
  `from` int(10) unsigned NOT NULL,
  `to` int(10) unsigned NOT NULL,
  `type` tinyint(3) unsigned NOT NULL,
  KEY `ix__metarelation__from` (`from`),
  KEY `ix__metarelation__to` (`to`)
) ENGINE=InnoDb DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;

CREATE TABLE `metalink` (
  `metaattribute` int(10) unsigned NOT NULL,
  `object` int(10) unsigned NOT NULL,
  `linkedobject` int(10) unsigned NOT NULL,
  KEY `ix__metalink__metaattribute` (`metaattribute`),
  KEY `ix__metalink__object` (`object`),
  KEY `ix__metalink__linkedobject` (`linkedobject`)
) ENGINE=InnoDb DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;