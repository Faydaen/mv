<?php
/**
 * Полезные функции
 *
 */
class HtmlTools
{
    // Словари

    /**
     * Названия месяцев
     *
     * @var array
     */
    public static $months = array('', 'январь', 'февраль', 'март', 'апрель', 'май', 'июнь', 'июль', 'август', 'сентябрь', 'октябрь', 'ноябрь', 'декабрь');

    /**
     * Короткие названия месяцев
     *
     * @var array
     */
    public static $monthsShort = array('', 'янв', 'фев', 'мар', 'апр', 'май', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек');

    /**
     * Названия месяцев в родительном падеже
     *
     * @var array
     */
    public static $months2 = array('', 'января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря');

    /**
     * Названия дней недели
     *
     * @var array
     */
    public static $weekDays = array('', 'понедельник', 'вторник', 'среда', 'четверг', 'пятница', 'суббота', 'воскресенье');

	/**
     * Названия дней недели в винительном падеже
     *
     * @var array
     */
    public static $weekDaysV = array('', 'понедельник', 'вторник', 'среду', 'четверг', 'пятницу', 'субботу', 'воскресенье');

    /**
     * Короткие названия дней недели
     *
     * @var array
     */
    public static $weekDaysShort = array('', 'пн', 'вт', 'ср', 'чт', 'пт', 'сб', 'вс');

    // Функции

    /**
     * Форматировать строку с денежной суммой
     *
     * @param float $money
     * @param int $decPlaces
     * @param string $symbol
     * @return string
     */
    static public function formatMoney($money, $decPlaces=0, $symbol='')
    {
        return number_format($money, $decPlaces, ',', ' ') . ($symbol == '' ? '' : ' ' . $symbol);
    }

    /**
     * Преобразовать SQL datetime в нормальный вид
     *
     * @param string $dateTime
     * @param bool $showTime
     * @param bool $monthAsName
     * @param bool $shortMonthNames
     * @return string
     */
    public static function formatDateTime ($dateTime, $showTime=true, $monthAsName=true, $shortMonthNames=false, $showSeconds = false)
    {
        $dt = explode(' ', $dateTime);
        $d = explode('-', $dt[0]);
		//if ($d[0]==date("Y")) $d[0] = '';
		//else $d[0] = ' '.$d[0];
        return (int)$d[2] . ($monthAsName ? ' '.($shortMonthNames ? self::$monthsShort[(int) $d[1]] : self::$months2[(int) $d[1]]).' ' : '.' . $d[1] . '.') . $d[0] .
            ($showTime ? ' ' . substr($dt[1], 0, ($showSeconds ? 8 : -3)) : '');
    }

	/**
     * Отображение дня недели
     *
     * @param string $dateTime
     * @param bool $v
     * @param bool $shortWeekDays
     * @return string
     */
    public static function formatWeekDay ($dateTime, $v = false, $shortWeekDays = false)
	{
		$dt = explode(' ', $dateTime);
		$day = date ("w", strtotime ($dt[0]));
		if ($day == 0) {
			$day = 7;
        }
		if ($shortWeekDays) {
			return self::$weekDaysShort[$day];
		} elseif ($v) {
			return self::$weekDaysV[$day];
		} else {
			return self::$weekDays[$day];
		}
	}


    /**
     * Форматировать размер файла
     *
     * @param int $size
     * @return string
     */
    public static function formatFileSize($size)
    {
        $sizes = array('б', 'кб', 'мб', 'гб');
        $i = 0;
        while ($size > 1024) {
        	$size /= 1024;
        	$i++;
        }
        return round($size, 2) . ' ' . $sizes[$i];
    }

    /**
     * Генерация <option> для <select>
     *
     * @param mixed $query - SQL запрос или массив значений
     * @param int $selectedId - Значение выделенного <option>
     * @return string
     */
    public static function generateOptions($query, $selectedId=0)
    {
        $sql = SqlDataSource::getInstance();
        if (is_string($query)) {
            $list = $sql->getRecordSet($query);
            $options = '';
            if ($list) {
                foreach ($list as $item) {
                    $options .= '<option value="' . $item['id'] . '" ' . ($item['id'] == $selectedId ? 'selected="selected"' : '') . '>' . $item['name'] . '</option>';
                }
            }
        } elseif (is_array($query)) {
            $options = '';
            foreach ($query as $i => $item) {
                if (is_array($item)) {
                    $value = $item['id'] ? $item['id'] : $item[0];
                    $name = $item['name'] ? $item['name'] : $item[0];
                } else {
                    $value = $i;
                    $name = $item;
                }
                $options .= '<option value="' . $value . '" ' . ($value == $selectedId ? 'selected="selected"' : '') . '>' . $name . '</option>';
            }
        }
        return $options;
    }

    /**
     * Генерация <option> для <select> с последовательными числами
     *
     * @param int $from
     * @param int $to
     * @param int $selectedValue
     * @param int $step
     * @return string
     */
    static public function generateOptionsCounter($from, $to, $selectedValue, $step=1)
    {
        $html = '';
        for ($i = $from; $i <= $to; $i += $step) {
            $html .= '<option value="' . $i . '" '.($selectedValue == $i ? 'selected="selected"' : '') . '>' . $i . '</option>';
        }
        return $html;
    }

    /**
     * Типографировать текст
     *
     * @param string $Str
     * @return string
     */
    /*
    {
        Std::LoadLib('typograph');
        return Typograph::process($Str);
    }
	*/


    /**
     * Отображение правильной формы существительного, следующего за числительным
     *
     * @param int $n
     * @param string $form1 - строка для >1 и <5
     * @param string $form2 - строка для >10 и <20
     * @param string $form3 - строка лоя всех остальных чисел
     * @return string
     */
	public static function russianNumeral($n, $form1, $form2, $form3)
	{
		$n = abs($n) % 100;
		$n1 = $n % 10;
		if ($n1 > 1 && $n1 < 5) {
            return $form1;
        } elseif ($n > 10 && $n < 20) {
            return $form2;
        } elseif ($n1 == 1) {
            return $form3;
        }
		return $form2;
	}
}
?>