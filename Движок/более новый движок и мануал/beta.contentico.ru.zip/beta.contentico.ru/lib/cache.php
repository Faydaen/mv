<?php
/**
 * Класс для работы с memcached
 */
class Cache extends Memcache
{
    private $sql;

	public function  __construct()
	{
		//parent::__construct();
		//parent::addServer(config::MEMCACHED_HOST, 11211);

        $this->sql = SqlDataSource::getInstance();
	}

    public function close()
    {
        //parent::close();
    }

	public function  __wakeup()
	{
		parent::pconnect(config::MEMCACHED_HOST, 11211);
	}

	public function  __sleep()
	{
		parent::close();
	}

    /**
     * Получить значение из кеша
     *
     * @var string $key
     * @return 
     */
    public function get($key)
    {
        return parent::get($key);
    }

	public function set($key, $var, $expire = 0, $flag = 0)
	{
		return parent::set($key, $var, $flag, $expire);
	}

    // SQL запросы с автоматическим кешем

    public function getSqlValue($query, $cacheTimeout = 0)
    {
        return $this->getSqlData($query, $cacheTimeout, "value");
    }

    public function getSqlRecord($query, $cacheTimeout = 0)
    {
        return $this->getSqlData($query, $cacheTimeout, "record");
    }

    public function getSqlRecordSet($query, $cacheTimeout = 0)
    {
        return $this->getSqlData($query, $cacheTimeout, "recordset");
    }

    private function getSqlData($query, $cacheTimeout, $resultType)
    {
        $key = md5($query);
        $data = $this->get($key);
        if ($data === false) {
            switch ($resultType) {
                case "value":
                    $data = $this->sql->getValue($query);
                    break;
                case "record":
                    $data = $this->sql->getRecord($query);
                    break;
                case "recordset":
                    $data = $this->sql->getRecordSet($query);
                    break;
            }
            $this->set($key, $data, $cacheTimeout);
        }
        return $data;
    }
}
?>
