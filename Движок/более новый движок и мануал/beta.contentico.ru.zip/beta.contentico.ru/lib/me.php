<?php
/* 
 * Специальный класс для хранения и быстрого вызова служебных классов
 */

/**
 * 
 */
class me
{
    /**
     * Объект для работы с SQL
     *
     * @var object
     */
    public static $sql;

    /**
     * Объект для работы с memcached
     *
     * @var object
     */
    public static $cache;

    /**
     * Массив для хранения переменных
     *
     * @var array
     */
    private static $var = array();

    /**
     * ID авторизованного пользователя
     *
     * @var int
     */
    public static $uid = 0;
    /**
     * ID группы авторизованного пользователя
     *
     * @var int
     */
    public static $gid = 0;

    /**
     * Список загруженных классов
     *
     * @var array
     */
    public static $loadedLibs = array();

    /**
     * Инициализация
     */
    public static function initRuntime()
    {
        self::$var = array();
        //
        if (is_array($_SESSION["_" . (CONTENTICO ? '_' : '') . 'me'])) {
            foreach ($_SESSION["_" . (CONTENTICO ? '_' : '') . 'me'] as $var => $value) {
                self::$var[$var] = $value;
            }
        }
        //
        self::$uid = $_SESSION["_" . (CONTENTICO ? '_' : '') . 'me']['uid'];
        self::$gid = $_SESSION["_" . (CONTENTICO ? '_' : '') . 'me']['gid'];
    }

    /**
     * Получение значения
     *
     * @param string $var
     * @return mixed
     */
    public static function get($var, $defaultValue = false)
    {
		return isset(self::$var[$var]) ? self::$var[$var] : $defaultValue;
    }

    /**
     * Установка значения
     *
     * @param string $var
     * @param mixed $value
     */
    public static function set($var, $value)
    {
		$_SESSION[(CONTENTICO ? '_' : '') . 'me'][$var] = $value;
		self::$var[$var] = $value;
    }

    /**
     * Удаление переменной
     *
     * @param string $Var
     */
    public static function clear($var)
    {
        unset($_SESSION[(CONTENTICO ? '_' : '') . 'me'][$var]);
        unset(self::$var[$var]);
    }
}
?>
