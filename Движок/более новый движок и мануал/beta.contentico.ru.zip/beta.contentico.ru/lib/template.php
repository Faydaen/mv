<?php
/* 
 * Шаблонизитор
 */
class Template implements ArrayAccess, Iterator, Countable
{
    /**
     * Массив для хранения значений при работе с объектом как с массивом
     *
     * @var array
     */
    private $container = array();

    /**
     * HTML шаблон
     *
     * @var string
     */
    public $template;

    public function __construct()
    {

    }

    /**
     * Установка шаблона
     *
     * @param string $template
     */
    public function setTemplate($template)
    {
        $this->template = $template;
    }

    /**
     * Загрузка шаблона
     *
     * @param string $templatePath - Путь внутри каталога "_tpl/"
     */
    public function loadTemplate($templatePath)
    {
        $this->template = file_get_contents("_tpl/" . $templatePath . ".html");
    }

    /**
     * Сборка шаблона в HTML
     *
     * @return string
     */
    public function getHtml()
    {
        $html = $this->template;
        foreach ($this as $placeHolder => $template) {
            $html = str_replace("<%" . $placeHolder . "%>", (is_object($template) ? $template->getHtml() : $template), $html);
        }
        return $html;
    }

    // Служебные методы для возможности работать с объектом, как с массивом

    public function offsetSet($offset, $value)
    {
        if ($offset == "") {
            $this->container[] = $value;
        } else {
            $this->container[$offset] = $value;
        }
    }

    public function offsetExists($offset)
    {
        return isset($this->container[$offset]);
    }

    public function offsetUnset($offset)
    {
        unset($this->container[$offset]);
    }

    public function offsetGet($offset)
    {
        return isset($this->container[$offset]) ? $this->container[$offset] : null;
    }

    public function rewind()
    {
        reset($this->container);
    }

    public function current()
    {
        return current($this->container);
    }

    public function key()
    {
        return key($this->container);
    }

    public function next()
    {
        return next($this->container);
    }

    public function valid()
    {
        return $this->current() !== false;
    }

    public function count()
    {
        return count($this->container);
    }
}
?>