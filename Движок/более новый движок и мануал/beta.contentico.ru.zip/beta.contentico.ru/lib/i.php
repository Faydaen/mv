<?php
include('_lib/ds/i.php');
include('_lib/ui/i.php');

interface IModule
{
    public function processRequest();
}

interface IBaseModule
{
    public function processRequest();

    public function getHtml();

    public function onBeforeProcessRequest();

    public function onAfterProcessRequest();
}
?>