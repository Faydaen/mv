<?php
/**
 * Отправка отладочной информации в консоль FirePHP (www.firephp.org)
 * На основе протокола: http://www.firephp.org/Wiki/Reference/Protocol
 */
class debug
{
    private static $counter = 1;
    
    private static $initiated = false;
    
    /**
     * Виды иконок в консоле слева от сообщения
     */
    const LOG = 'LOG';
    const INFO = 'INFO';
    const WARN = 'WARN';
    const ERROR = 'ERROR';

    /**
     * Инициализация консоли FirePHP
     */
    private static function init()
    {
        header("X-Wf-Protocol-1: http://meta.wildfirehq.org/Protocol/JsonStream/0.2");
        header("X-Wf-1-Plugin-1: http://meta.firephp.org/Wildfire/Plugin/FirePHP/Library-FirePHPCore/0.3");
        header("X-Wf-1-Structure-1: http://meta.firephp.org/Wildfire/Structure/FirePHP/FirebugConsole/0.1");
    }

    /**
     * Отправка сообщения в консоль FirePHP
     *
     * @var mixed $message
     * @var int $messageType
     */
    public static function fireDump($message, $messageType = debug::LOG, $file = "", $line = "")
    {
        if (!self::$initiated) {
            self::init();
        }

        $params = array(
            "Type" => $messageType,
            "File" => $file,
            "Line" => $line,
        );

        if (is_array($message)) {
            $message = std::arrayToJson($message);
        } else {
            $message = '"' . str_replace('"', "'", $message) . '"';
        }
        $message = "[" . std::arrayToJson($params) . "," . $message . "]";

        header("X-Wf-1-1-1-" . self::$counter . ": " . strlen($message) . "|" . $message . "|");

        self::$counter++;
    }
}
?>
