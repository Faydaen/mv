<?php
/**
 * Стандартные функции
 *
 */
class std
{	
    /**
     * Обработка строки для SQL запроса
     *
     * @param string $String
     * @return string
     */
    public static function cleanString($string)
    {
        return mysql_real_escape_string(trim($string));
    }

    /**
     * Загрузка HTML шаблона
     *
     * @param string $Template
     * @return string
     */
    public static function loadTemplate ($template)
    {
        return file_get_contents('tpl/'.$template.'.html');
    }

    /**
     * Загрузка библиотеки
     *
     * @param string $Lib
     */
    public static function loadLib($lib)
    {
        if (!class_exists("Runtime") || (!in_array($lib, Runtime::$loadedLibs) && !class_exists($lib))) {
            include('lib/'.strtolower($lib).'.php');
            me::$loadedLibs[] = $lib;
        }
    }

    /**
     * Загрузка модуля с переводами текстов
     *
     */
    public static function loadLang()
    {
        global $configProject;

        if ($configProject['lang'] != '') {
            if (!class_exists('Runtime') || (!in_array('Lang', Runtime::$loadedLibs) && !class_exists('Lang'))) {
                include('mod/lang/'.$configProject['lang'] . '.php');
                me::$loadedLibs[] = 'Lang';
            }
        }
    }

    /**
     * Загрузка класса метаобъекта
     *
     * @param string $metaObjectCode
     */
    public static function loadMetaObjectClass($metaObjectCode)
    {
        if (!in_array($metaObjectCode . 'Object', Runtime::$loadedLibs)
                && file_exists('obj/' . strtolower($metaObjectCode) . '.base.php')
                && file_exists('obj/'.strtolower($metaObjectCode) . '.php')) {
            include('obj/'.strtolower($metaObjectCode) . '.base.php');
            include('obj/'.strtolower($metaObjectCode) . '.php');
            me::$loadedLibs[] = $metaObjectCode . 'Object';
        }
    }

    /**
     * Загрузка расширения для метаобъекта
     *
     * @param string $metaObjectCode
     * @return bool
     */
    public static function loadMetaObjectExtention($metaObjectCode)
    {
        if (in_array($metaObjectCode.'Extention', Runtime::$loadedLibs)) {
            return true;
        }
        if (file_exists('obj/' . strtolower($metaObjectCode) . '.ext.php')) {
            include('obj/' . strtolower($metaObjectCode) . '.ext.php');
            me::$loadedLibs[] = $metaObjectCode . 'Extention';
            return true;
        } else {
            return false;
        }
    }

    /**
     * Загрузка модуля
     *
     * @param string $module
     */
    public static function loadModule($module)
    {
        if (!in_array($module . 'Module', Runtime::$loadedLibs) && !class_exists($module)) {
            include('mod/'.strtolower($module) . '.php');
            me::$loadedLibs[] = $module . 'Module';
        }
    }

    /**
     * Редирект
     *
     * @param string $Url
     * @param bool $stopExecution
     */
    public static function redirect($url)
    {
        header('Location: ' . $url);
        exit;
    }

    /**
     * Перевод строки в транслит
     *
     * @param string $str
     * @param bool $uniqueName
     * @return string
     */
    public static function translit($str, $uniqueName = false)
    {
        //$str = str_replace(' ', '-', $str);
        $ru = array('А','Б','В','Г','Д','Е','Ё','Ж','З','И','Й','К','Л','М','Н','О','П','Р','С','Т','У','Ф','Х','Ц','Ч','Ш','Щ','Ъ','Ы','Ь','Э','Ю','Я','а','б','в','г','д','е','ё','ж','з','и','й','к','л','м','н','о','п','р','с','т','у','ф','х','ц','ч','ш','щ','ъ','ы','ь','э','ю','я');
        $en = array('A','B','V','G','D','E','E','G','Z','I','J','K','L','M','N','O','P','R','S','T','U','F','H','C','CH','SH','SCH','','I','','E','U','YA','a','b','v','g','d','e','e','g','z','i','j','k','l','m','n','o','p','r','s','t','u','f','h','c','ch','sh','sch','','y','','e','u','ya');
        $str = str_replace($ru, $en, $str);
        $str = preg_replace("/[^a-zA-Z0-9_\.-]/", '', $str);
        if ($uniqueName) {
            $str = mt_rand(100001, 999999) . '__' . $str;
        }
        return $str;
    }

    /**
     * Определение IP адреса
     *
     * @return string
     */
    public static function getClientIP()
    {
        return $_SERVER['REMOTE_ADDR'];
        if (getenv("HTTP_CLIENT_IP")) {
            $ip = getenv("HTTP_CLIENT_IP");
        } elseif (getenv("HTTP_X_FORWARDED_FOR") && (!strstr(getenv("HTTP_X_FORWARDED_FOR"), "192.168.") && (!strstr(getenv("HTTP_X_FORWARDED_FOR"), "255.255.255.")))) {
            $ip = getenv("HTTP_X_FORWARDED_FOR");
        } elseif (getenv("REMOTE_ADDR")) {
            $ip = getenv("REMOTE_ADDR");
        } else {
            $ip = "";
        }
        return $ip;
    }

    /**
     * Генерация HTML на основе шаблона и данных
     *
     * @param string $Template
     * @param array $Data
     * @return string
     */
    public static function renderTemplate($template, $data)
    {
        if (is_array($data)) {
            foreach ($data as $field => $value) {
                $template = str_replace('<%' . $field . '%>', $value, $template);
            }
        }
        return $template;
    }

    /**
     * Генерация списка страниц
     *
     * @param int $Total - всего элементов
     * @param int $OnPage - элементов на странице
     * @param int $CurPage - номер текущей старницы, начиная с 1
     * @param string $Href - ссылка, к которой будет приписано "<номер-страницы>/"
     * @param bool $ShowIfOnePage - показывать ссылки если всего одна страница
     * @param int $Show - кол-во ссылок справа/слева от текущей
     * @return string
     */
    public static function renderNavigation($total, $onPage, $curPage, $href, $showIfOnePage=true, $show=2)
    {
        $prev_templ = self::loadTemplate('nav/prev');
        $prev_dis_templ = self::loadTemplate('nav/prev_disabled');
        $pagenumlink_template = self::loadTemplate('nav/pagenumberlink');
        $current_template = self::loadTemplate('nav/current');
        $next_templ = self::loadTemplate('nav/next');
        $next_dis_templ = self::loadTemplate('nav/next_disabled');
        $sep_templ = self::loadTemplate('nav/separator');
        $nav_templ = self::loadTemplate('nav/nav');
        //
        $pages = ($total - ($total % $onPage)) / $onPage;
        if($Total > ($pages * $onPage)) {
            $pages++;
        }
        if (($pages > 1) || ($showIfOnePage)) {
            $pageNums = array();
            for ($i =- $show; $i <= $show; $i++) {
                $link = '';
                if ($i == 0) {
                    $pageNums[] = str_replace(array('<%page_no%>', '<%href%>'), array($curPage, $href.$curPage.'/'), $current_template);
                } else {
                    $n = $curPage + $i;
                    if (($n > 0) && ((($n * $onPage) == $total) || ((($n - 1) * $onPage) < $total))) {
                        $pageNums[] = str_replace(array('<%page_no%>', '<%href%>'), array($n, $href.$n.'/'), $pagenumlink_template);
                    }
                }
            }
            // 1 ... 5 6 7
            if ($curPage - $show > 1) {
                $link = str_replace(array('<%page_no%>', '<%href%>'), array(1, $href.'1/'), $pagenumlink_template);
                if ($curPage - $show > 2) {
                    $link .= $sep_templ.' &hellip; ';
                }
                array_unshift($pageNums, $link);
            }
            // 1 2 3 ... 7
            if ($pages - $curPage > $show) {
                $link = '';
                if ($pages - $curPage > $show + 1) {
                    $link = ' &hellip; '.$sep_templ;
                }
                $link .= str_replace(array('<%page_no%>', '<%href%>'), array($pages, $href.$pages.'/'), $pagenumlink_template);
                array_push($pageNums, $link);
            }
            // первая, назад, вперед, последняя
            $prev = str_replace('<%href%>', $href.($curPage - 1), ($curPage > 1 ? $prev_templ : $prev_dis_templ));
            $next = str_replace('<%href%>', $href.($curPage + 1), ($curPage < $Pages ? $next_templ : $next_dis_templ));
            return std::renderTemplate($nav_templ, array(
                'prev'=>$prev,
                'next'=>$next,
                'sep'=>$sep_templ,
                'pages'=>implode($sep_templ, $pageNums),
            ));
        } else {
            return '';
        }
    }

    /**
     * Проверка прав доступа
     *
     * @param int $metaObjectId
     * @param int $objectId
     * @param int $rights
     * @param int $userId
     * @return bool
     */
    public static function checkUserRightsOnObject($metaObjectId, $objectId, $rights, $userId=0)
    {
        $sql = SqlDataSource::getInstance();
        if (!is_numeric($metaObjectId)) {
            $metaObjectId = $sql->getValue("SELECT id FROM metaobject WHERE code='$metaObjectId'");
        }
        return $sql->getValue("SELECT checkUserRightsOnObject($metaObjectId, $objectId, ".Runtime::$gid.", $rights");
    }

    /**
     * Проверка загруженного файла на безопасность
     *
     * @param array $file - $_FILES[*]
     * @param string $type - {image, file}
     * @return bool
     */
    public static function testUploadedFile($file, $type)
    {
        switch ($type) {
            case 'image':
                $ext = explode('.', $file['name']);
                $ext = strtolower($ext[count($ext)-1]);
                if ($ext == 'jpg' || $ext == 'jpeg' || $ext == 'gif' || $ext == 'png') {
                    switch ($ext) {
                        case 'jpg': 
                        case 'jpeg':
                            $func = 'imagecreatefromjpeg';
                            break;

                        case 'gif':
                            $func = 'imagecreatefromgif';
                            break;

                        case 'png': 
                            $func = 'imagecreatefrompng';
                            break;
                    }
                    $img = $func($file['tmp_name']);
                    if (!$img) {
                        return false;
                    } else {
                        imagedestroy($img);
                        return true;
                    }
                } else {
                    return false;
                }
                break;

            case 'file':
                $ext = explode('.', $file['name']);
                $ext = strtolower($ext[count($ext)-1]);
                $scriptExt = array('php','php3','php4','php5','phtml','pl','cs','vb','aspx');
                return (in_array($ext, $scriptExt)) ? false : true;
                break;
        }
    }

    /**
     * Отправить e-mail
     *
     * @param strign $email
     * @param string $subject
     * @param string $body
     * @param string $from
     * @param string $replyTo
     */
    public static function sendMail($email, $subject, $body, $from, $replyTo='', $fixUtf8=false)
    {
		$subject = "=?" . $GLOBALS['config']['headerCharset'] . "?B?" . base64_encode(iconv("UTF-8", $GLOBALS['config']['headerCharset'], $subject)) . "?=";
		$header = "From: " . "=?" . $GLOBALS['config']['headerCharset'] . "?B?" . base64_encode(iconv("UTF-8", $GLOBALS['config']['headerCharset'], $from)) . "?=" . " <" . $from . ">\r\n" .
            ($replyTo == '' ? '' : "Reply-To: " . $replyTo . "\r\n") .
            "Content-Type: text/html; charset=\"UTF-8\"\r\n";
		return mail($email, $subject, $body, $header);
    }

    /**
     * Упаковка массива в JSON
     *
     * @param array $array
     * @return string
     */
    public static function arrayToJson($array)
    {
        $items = array();
        foreach ($array as $key => $value) {
            $item = is_numeric($key) ? '' : '"'.$key.'":';
            $item .= is_array($value) ? self::arrayToJson($value) : '"'.str_replace('"', "&quot;", $value).'"';
            $items[] = $item;
        }
        return is_numeric($key) ? '['.implode(',', $items).']' : '{'.implode(',', $items).'}';
    }

    /**
     * Упаковка массива в XML
     *
     * @param array $array
     * @param bool $isRoot
     * @return string
     */
    public static function arrayToXml($array, $isRoot = true)
    {
        $xml = $isRoot ? '<?xml version="1.0" encoding="utf-8"?><contentico>' : '';
        foreach ($array as $key => $value) {
            $key = is_numeric($key) ? 'element' : $key;
            $xml .= '<'.$key.'>'.(is_array($value) ? self::arrayToXml($value, false) : str_replace(array('<','>'), array('&lt;','&gt;'), $value)).'</'.$key.'>';
        }
        $xml .= $isRoot ? '</contentico>' : '';
        return $xml;
    }
    
    /**
     * Поиск свободного имени для файла
     *
     * @param string $path
     * @param string $filesPath
     * @return string
     */
    public function getNextFreeFileName($path)
    {
        $i = 1;
        while (file_exists($path)) {
            $path = explode('.', $path);
            if ($i == 1) {
                $path[count($path)-2] .= '['.$i.']';
            } else {
                $path[count($path)-2] = str_replace('['.($i-1).']', '['.$i.']', $path[count($path)-2]);
            }
            $path = implode('.', $path);
            $i++;
        }
        return $path;
    }

    public static function dump($data, $cleanFile = false, $file = 'dump.txt')
    {
        if ($cleanFile) {
            file_put_contents($file, '');
        }
        if (is_array($data)) {
            $data = json_encode($data);
        }
        file_put_contents($file, file_get_contents($file) . PHP_EOL . date('Y-m-d H:i:s', time()) . "\t" . Runtime::$uid . "\t" . $data);
    }

    public static function sortRecordSetByField(&$recordSet, $field, $sortOrder = 1)
    {
        $setForSorting = array();
        for ($i = 0, $len = sizeof($recordSet); $i < $len; $i++) {
            $setForSorting["$i"] = is_numeric($recordSet[$i][$field]) ? (int)$recordSet[$i][$field] : $recordSet[$i][$field];
        }
        if ($sortOrder == 1) {
            asort($setForSorting);
        } else {
            arsort($setForSorting);
        }
        $recordSet2 = $recordSet;
        $recordSet = array();
        foreach ($setForSorting as $i => $fieldValue) {
            $recordSet[] = $recordSet2[$i];
        }
    }
}
?>