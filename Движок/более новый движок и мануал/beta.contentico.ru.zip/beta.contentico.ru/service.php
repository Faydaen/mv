<?php
include("config.php");
include("config2.php");
include("lib/const.php");
include("lib/i.php");
include("lib/ds/" . config::DB_TYPE . ($_COOKIE["contentico__sql_debug"] == 1 ? ".debug" : "") . ".php");
include("lib/std.php");
include("lib/debug.php");
include("lib/cache.php");
include("lib/me.php");
include("obj/object.php");
include("lib/objectcollection.php");
include("mod/const.php");
include("mod/page.php");

define("CONTENTICO", false);
define("SHELL", isset($_SERVER["REQUEST_METHOD"]) ? false : true);

session_start();

$sql = SqlDataSource::getInstance();

// скрипт вызван из командной строки
if (SHELL) {
    // первый аргумент из командной строки - модуль
    $moduleCode = $argv[1];
    // загрузка класса модуля
    Std::loadModule($moduleCode);
    // инициализация модуля
    $module = new $moduleCode();
    // обработка оставшихся аргументов из командной строки
    for ($i = 2, $j = sizeof($argv); $i < $j; $i++) {
        $module->shellArgs[] = $argv[$i];
    }
    // обработка запроса
    $module->processRequest();

// скрипт вызван через URL
} else {
    switch ($_GET["_a"]) {
        // отправка файла на скачивание
        case "file":
            sendFileToDownload();
            break;

        // удаленные SQL запросы
        case "remotesql":
            remoteSql();
            break;
    }
}

/**
 * Отправка файла на скачивание
 */
function sendFileToDownload()
{
    $file = $sql->getRecord("SELECT name, path, size FROM stdfile WHERE id = " . (int)$_GET["id"]);
    if ($file) {
        header("Content-Disposition: attachment; filename=\"".$file["name"]."\"");
        header("Content-Transfer-Encoding: binary");
        header("Content-Length: ".$file["size"]);
        header("HTTP/1.0 200 OK");
        header("Cache-Control: max-age=3600, must-revalidate");
        readfile("files/" . $file["path"]);
    } else {
        header("HTTP/1.0 404 Not Found");
        file_get_contents("tpl/error/404.html");
    }
    exit;
}

/**
 * Удаленные SQL запросы
 */
function remoteSql()
{
    $email = Std::cleanString($_GET["email"]);
    $pwd = sha1(trim($_GET["pwd"]));
    $exportType = $_GET["export"];
    $userId = $sql->getValue("SELECT id FROM sysuser WHERE email = '" . $email . "' AND pwd = '" . $pwd . "' AND enabled = 1");
    if ($userId) {
        $queryType = $_GET["type"];
        $query = base64_decode($_GET["query"]);
        switch ($queryType) {
            case "getvalue":
                $result = $sql->getValue($query);
                break;

            case "getrecord":
                $result = $sql->getRecord($query);
                break;

            case "getrecordset":
                $result = $sql->getRecordSet($query);
                break;

            case "getinsert":
                $result = $sql->insert($query);
                break;

            case "query":
            default:
                $result = $sql->query($query);
                break;
        }
        echo $exportType == "json" ? Std::arrayToJson($result) : Std::arrayToXml($result);
    } else {
        echo $exportType == "json" ?
            Std::arrayToJSON(array("error" => "Authentication failed")) :
            Std::arrayToXml(array("error" => "Authentication failed"));
    }
}
?>