<?php
class config
{
    const DB_TYPE = "mysql";
    const DB_HOST = "localhost";
    const DB_USER = "root";
    const DB_PWD  = "3x1st4nz3";
    const DB_NAME = "contentico";
    const DB_PERSISTANT = true;

    const MEMCACHED_HOST = "localhost";

    const ADVANCED_SECURITY = false;
    const CACHE = true;
    const SHOW_ERRORS = true;

    const LANG = "ru";
}

if (config::SHOW_ERRORS && $_COOKIE['contentico__php_errors'] == 1) {
	error_reporting(E_ALL ^ E_NOTICE);
	ini_set("error_reporting", E_ALL ^ E_NOTICE);
} else {
	error_reporting();
	ini_set("error_reporting", "off");
}

?>