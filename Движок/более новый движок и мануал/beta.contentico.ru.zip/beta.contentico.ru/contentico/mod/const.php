<?php
/* 
 * Константы
 */

define('ACTION_LIST', 1);
define('ACTION_VIEW', 2);
define('ACTION_CREATE', 3);
define('ACTION_EDIT', 4);
define('ACTION_DELETE', 5);
define('ACTION_CUSTOM', 9);
?>
