<?php
include("config.php");
include("config2.php");
include("lib/i.php");
include("lib/ds/" . config::DB_TYPE . ($_COOKIE["contentico__sql_debug"] == 1 ? ".debug" : "") . ".php");
include("lib/std.php");
include("lib/runtime.php");
include("lib/const.php");
include("lib/ui/element.php");
include("lib/contentico.php");
include("obj/object.php");
include("lib/objectcollection.php");
include("contentico/mod/const.php");
include("contentico/mod/module.php");

define("CONTENTICO", true);

session_start();

$moduleCode = $_GET["_m"] ? preg_replace("/[^\w]/", "", $_GET["_m"]) : "Index";
Contentico::loadModule($moduleCode);
$module = new $moduleCode();
$module->processRequest();
$module->renderPage();
?>