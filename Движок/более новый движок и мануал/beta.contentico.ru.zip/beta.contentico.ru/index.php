<?php
include('config.php');
include('config2.php');
include('lib/const.php');
include('lib/i.php');
include('lib/ds/' . config::DB_TYPE . ($_COOKIE['contentico__sql_debug'] == 1 ? '.debug' : '') . '.php');
include('lib/std.php');
include('lib/debug.php');
include('lib/cache.php');
include('lib/me.php');
include('obj/object.php');
include('lib/objectcollection.php');
include('mod/const.php');
include('mod/page.php');

define('CONTENTICO', false);
define('SHELL', isset($_SERVER['REQUEST_METHOD']) ? false : true);

debug::fireDump("test-123", debug::WARN, __FILE__, __LINE__);

$moduleCode = $_GET['_m'] ? preg_replace('/[^\w]/', '', $_GET['_m']) : 'Page';
if ($moduleCode == 'Page') {
    $module = new Page();
    exit;
    $module->getPage();
    if ($module->moduleCode != 'Page') {
        $moduleCode = $module->moduleCode;
    }
}
if ($moduleCode != 'Page') {
	Std::loadModule($moduleCode);
    $module = new $moduleCode();
}
$module->processRequest();
$module->getHtml();
?>